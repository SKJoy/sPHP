<?php
//? Application wide library functions

function MyApplicationLibraryFunction($Argument = null){

	return $Argument;
}
?>