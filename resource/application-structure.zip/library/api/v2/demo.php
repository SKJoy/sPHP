<?php
namespace API\V2;

class TerminalData{
	#region Constants
	public const ERROR_NO_ERROR = 0;
	public const ERROR_UNKNOWN = 1;
	public const ERROR_DATABASE_QUERY = 2;
	public const ERROR_DATABASE_DATA_INSUFFICIENT = 3;
	public const ERROR_DATABASE_NO_DATA = 4;
	public const ERROR_MISSING_ARGUMENT = 5;
	#endregion Constants

	private $Property = [ // Property storage
		"User" => null, 
		"Database" => null, 
		"Debug" => false, 
		"MaximumConsiderableGPSVelocity" => 9999, 
		"GPSJitterCorrectionMinimumDistance" => 0, 
		"MinimumPitStopDuration" => 600, // N seconds idle time to consider for a pit stop
	];

	#region System
	public function __construct($User = null, $Database = null, $Debug = null, $MaximumConsiderableGPSVelocity = null, $GPSJitterCorrectionMinimumDistance = null, $MinimumPitStopDuration = null){
		#region Set default property values for no scaler data
		$this->Property["User"] = \sPHP::$User;
		$this->Property["Database"] = \sPHP::$Database;
		$this->Property["MaximumConsiderableGPSVelocity"] = \sPHP::$Configuration["MaximumConsiderableGPSVelocity"];
		$this->Property["GPSJitterCorrectionMinimumDistance"] = \sPHP::$Configuration["GPSJitterCorrectionMinimumDistance"];
		$this->Property["MinimumPitStopDuration"] = \sPHP::$Configuration["MinimumPitStopDuration"];
		#endregion Set default property values for no scaler data

		#region Set property values from arguments
		foreach(array_filter(get_defined_vars()) as $Property => $Value)if(!is_null($Value))if(method_exists($this, $Property)){
			$this->$Property($Value);
		}
		else{
			$this->Property[$Property] = $Value;
		}
		#endregion Set property values from arguments
	}
	#endregion System

	#region Method
	public function List($TerminalDataTimeFrom = null, $TerminalDataTimeTo = null, $TerminalID = null, $TerminalAssignmentCode = null, $VehicleRouteMode = null, $NoCache = null, $MaximumConsiderableGPSVelocity = null, $GPSJitterCorrectionMinimumDistance = null, $MinimumPitStopDuration = null, $User = null, $Database = null, $Debug = null){
		#region Validate arguments
		// Get from object defaults
		if(is_null($User))$User = $this->Property["User"];
		if(is_null($Database))$Database = $this->Property["Database"];
		if(is_null($Debug))$Debug = \sPHP\SetVariable("Debug", $this->Property["Debug"]);
		
		// Set as user input defautls
		if(is_null($TerminalDataTimeFrom))$TerminalDataTimeFrom = \sPHP\SetVariable("TerminalDataTimeFrom", date("Y-m-d 00:00:00"));
		if(is_null($TerminalDataTimeTo))$TerminalDataTimeTo = \sPHP\SetVariable("TerminalDataTimeTo", date("Y-m-d 23:59:59"));
		if(is_null($TerminalID))$TerminalID = \sPHP\SetVariable("TerminalID");
		if(is_null($TerminalAssignmentCode))$TerminalAssignmentCode = \sPHP\SetVariable("TerminalAssignmentCode");
		if(is_null($VehicleRouteMode))$VehicleRouteMode = \sPHP\SetVariable("VehicleRouteMode", true);
		if(is_null($NoCache))$NoCache = \sPHP\SetVariable("NoCache", false);
		
		// Set as user input defaults to object defaults
		if(is_null($MaximumConsiderableGPSVelocity))$MaximumConsiderableGPSVelocity = \sPHP\SetVariable("MaximumConsiderableGPSVelocity", $this->Property["MaximumConsiderableGPSVelocity"]);
		if(is_null($GPSJitterCorrectionMinimumDistance))$GPSJitterCorrectionMinimumDistance = \sPHP\SetVariable("GPSJitterCorrectionMinimumDistance", $this->Property["GPSJitterCorrectionMinimumDistance"]);
		if(is_null($MinimumPitStopDuration))$MinimumPitStopDuration = \sPHP\SetVariable("MinimumPitStopDuration", $this->Property["MinimumPitStopDuration"]);
		#endregion Validate arguments
		
		#region Transform arguments
		#region Validate input time for data period
		// Although validation is already put in the database end, we need this here to determine cache file name
		$TerminalDataTimePeriodSecondNormal = 24 * 60 * 60;
		$TerminalDataTimePeriodSecondMaximum = 7 * $TerminalDataTimePeriodSecondNormal; // Limit by N days

		$TerminalDataTimeFrom = strtotime($TerminalDataTimeFrom);
		if($TerminalDataTimeFrom > time())$TerminalDataTimeFrom = strtotime(date("Y-m-d 00:00:00"));
		
		$TerminalDataTimeTo = strtotime($TerminalDataTimeTo);
		if($TerminalDataTimeTo < $TerminalDataTimeFrom)$TerminalDataTimeTo = $TerminalDataTimeFrom + $TerminalDataTimePeriodSecondNormal - 1;
		if($TerminalDataTimeTo - $TerminalDataTimeFrom > $TerminalDataTimePeriodSecondMaximum)$TerminalDataTimeTo = $TerminalDataTimeFrom + $TerminalDataTimePeriodSecondMaximum - 1;
		if($TerminalDataTimeTo > time())$TerminalDataTimeTo = strtotime(date("Y-m-d 23:59:59"));
		
		$TerminalDataTimeFrom = date("Y-m-d H:i:s", $TerminalDataTimeFrom);
		$TerminalDataTimeTo = date("Y-m-d H:i:s", $TerminalDataTimeTo);
		#endregion Validate input time for data period

		if(!is_array($TerminalID))$TerminalID = array_filter(explode(",", str_replace(" ", null, $TerminalID)));
		if(!is_array($TerminalAssignmentCode))$TerminalAssignmentCode = array_filter(explode(",", str_replace(" ", null, $TerminalAssignmentCode)));

		$MaximumConsiderableGPSVelocity = floatval($MaximumConsiderableGPSVelocity);
		$GPSJitterCorrectionMinimumDistance = floatval($GPSJitterCorrectionMinimumDistance);
		$MinimumPitStopDuration = intval($MinimumPitStopDuration);
		#endregion Transform arguments
	
		$Response = [ // Default API response
			"Error" => [
				"Code" => $this::ERROR_NO_ERROR,
				"Description" => null,
			],
			"Response" => [				
				"MotionState" => [], 
				"Data" => [],
				"GeoLocation" => [], 
				"Terminal" => [],
				"Event" => [],
			], 
			"Documentation" => [
				"API" => [
					"Argument" => [
						"TerminalDataTimeFrom" => ["Type" => "Date time string", "Required" => false, "Sample" => "2021-08-01 09:40:15", "Description" => "Beginning time of data to get for", "Default" => "Today", ],
						"TerminalDataTimeTo" => ["Type" => "Date time string", "Required" => false, "Sample" => "2021-08-01 11:59:44", "Description" => "Ending time of data to get for", "Default" => "Today", ],
						"TerminalID" => ["Type" => "Integer | String", "Required" => false, "Sample" => "999999, 777777", "Description" => "Comma separated list of Terminal ID to get data for; use alternatively with TerminalAssignmentCode", "Default" => "NULL", ],
						"TerminalAssignmentCode" => ["Type" => "String", "Required" => false, "Sample" => "ABC888, XYZ666", "Description" => "Comma separated list of Terminal assignment code to get data for; use alternatively with TerminalID", "Default" => "NULL", ],
						"VehicleRouteMode" => ["Type" => "Integer", "Required" => false, "Sample" => "0 | 1", "Description" => "0 = All data; 1 = Filter data for vehicle route", "Default" => 1, ],
						//"NoCache" => ["Type" => "Boolean", "Required" => false, "Sample" => "0 | 1", "Description" => "0 = Use cache if available; 1 = Do not use cache; process real time", "Default" => false, ],
					],
					"Note" => [
						"At least TerminalID or TerminalAssignmentCode is required", 
						"Maximum data period is {$TerminalDataTimePeriodSecondMaximum} seconds beginning at TerminalDataTimeFrom argument", 
					], 
				],
			],
			"Diagnostics" => [
				//"Argument" => get_defined_vars(),
				"POST" => $_POST,
				"Database" => [
					"Argument" => [], 
				],
			],
		];

		if(count($TerminalID) || count($TerminalAssignmentCode)){ // Check if we have adequet parameter to proceed with processing
			#region Internal variables
			$TerminalDataTimeFromStamp = strtotime($TerminalDataTimeFrom);
			$UserID = intval($User->ID());
			$TerminalIDList = count($TerminalID) ? implode(", ", $TerminalID) : 0;
			$TerminalAssignmentCodeList = "'" . implode("', '", $TerminalAssignmentCode) . "'";

			#region Manage cache file
			$CachePath = \sPHP::$Environment->Path() . "template/cache/vehicleroute/" . date("Y/m/", $TerminalDataTimeFromStamp) . "UserID-{$UserID}/" . str_replace(str_split(" :"), "-", $TerminalDataTimeFrom) . "/" . str_replace(str_split(" :"), "-", $TerminalDataTimeTo) . "";
			if(!is_dir($CachePath))mkdir($CachePath, 0777, true); // Make sure we have the cache path
			$CacheFile = "{$CachePath}/" . md5(implode("|", $TerminalID)) . "-" . md5(implode("|", $TerminalAssignmentCode)) . ".json";
			#endregion Manage cache file
			#endregion Internal variables

			if( // Check if cache expired
				$NoCache || // Ignore and rebuild cache for Debug mode
				strtotime($TerminalDataTimeTo) > time() - (4 * 24 * 60 * 60) || // Stay behind 1 day from distance correction
				!file_exists($CacheFile) || // Cache not found
				time() - filemtime($CacheFile) > 366 * 24 * 60 * 60 // Cache expired of N days
			){ // Cache expired; process data
				#region Get data from database
				$SQL = "
					# Argument
						SET @ProcessTimeBegin := NOW();

						# Validate time range
							SET @TerminalDataTimePeriodSecondNormal := {$TerminalDataTimePeriodSecondNormal};
							SET @TerminalDataTimePeriodSecondMaximum := {$TerminalDataTimePeriodSecondMaximum};

							SET @TerminalDataTimeFrom := '{$Database->Escape($TerminalDataTimeFrom)}';
							SET @TerminalDataTimeFrom := IF(@TerminalDataTimeFrom = '', DATE_FORMAT(NOW(), '%Y-%m-%d 00:00:00'), @TerminalDataTimeFrom);
							SET @TerminalDataTimeFrom := IF(@TerminalDataTimeFrom > NOW(), DATE_FORMAT(NOW(), '%Y-%m-%d 00:00:00'), @TerminalDataTimeFrom);
			
							SET @TerminalDataTimeTo := '{$Database->Escape($TerminalDataTimeTo)}';
							SET @TerminalDataTimeTo := IF(@TerminalDataTimeTo = '', DATE_ADD(@TerminalDataTimeFrom, INTERVAL (@TerminalDataTimePeriodSecondNormal - 1) SECOND), @TerminalDataTimeTo);
							SET @TerminalDataTimeTo := IF(@TerminalDataTimeTo < @TerminalDataTimeFrom, DATE_ADD(@TerminalDataTimeFrom, INTERVAL (@TerminalDataTimePeriodSecondNormal - 1) SECOND), @TerminalDataTimeTo);
							SET @TerminalDataTimeTo := IF(TIME_TO_SEC(TIMEDIFF(@TerminalDataTimeTo, @TerminalDataTimeFrom)) > @TerminalDataTimePeriodSecondMaximum, DATE_ADD(@TerminalDataTimeFrom, INTERVAL (@TerminalDataTimePeriodSecondMaximum - 1) SECOND), @TerminalDataTimeTo);
							SET @TerminalDataTimeTo := IF(@TerminalDataTimeTo > NOW(), DATE_FORMAT(NOW(), '%Y-%m-%d 23:59:59'), @TerminalDataTimeTo);
		
						# User information
							SET @UserID = {$UserID};
							SET @UserGroupIdentifierHighest := (SELECT UG.UserGroupIdentifier FROM sphp_usergroup AS UG LEFT JOIN sphp_userusergroup AS UUG ON UUG.UserGroupID = UG.UserGroupID WHERE UUG.UserID = @UserID ORDER BY UG.UserGroupWeight DESC LIMIT 1);
						
						# Other
							SET @VehicleRouteMode := " . intval($VehicleRouteMode) . ";
							SET @MaximumConsiderableGPSVelocity := " . intval($MaximumConsiderableGPSVelocity) . ";
							SET @GPSJitterCorrectionMinimumDistance := " . intval($GPSJitterCorrectionMinimumDistance) . ";
							SET @MinimumPitStopDuration := " . intval($MinimumPitStopDuration) . ";
		
					# Motion state
						SELECT			1 AS ID, 2 AS MaximumKmH, 'Idle' AS Caption, '#9F9F9F' AS Color UNION # Silver
						SELECT			2 AS ID, 15 AS MaximumKmH, 'Slow' AS Caption, '#FFFF00' AS Color UNION # Yellow
						SELECT			3 AS ID, 60 AS MaximumKmH, 'Normal' AS Caption, '#FFA500' AS Color UNION # Orange
						SELECT			4 AS ID, NULL AS MaximumKmH, 'Speeding' AS Caption, '#FF0000' AS Color; # Red
		
					# Terminal
						DROP TEMPORARY TABLE IF EXISTS tmp_terminal;
		
						CREATE TEMPORARY TABLE tmp_terminal (
							ID BIGINT(20) NULL, 
							Identifier VARCHAR(255) NULL, 
							Code VARCHAR(255) NULL, 
							IsSuspended TINYINT(1) NULL, 
							CarrierTypeName VARCHAR(255) NULL, 
							CarrierTypeIconName VARCHAR(255) NULL, 
							CustomerName VARCHAR(255) NULL, 
							ProviderCode VARCHAR(255) NULL, 
							CarrierCaption VARCHAR(255) NULL, 
							INDEX (ID), 
							INDEX (Code)
						) ENGINE = MEMORY;
		
						INSERT INTO		tmp_terminal (
											ID, Identifier, Code, IsSuspended, 
											CarrierTypeName, CarrierTypeIconName, 
											CustomerName, 
											ProviderCode, 
											CarrierCaption
										)
						SELECT			TA.TerminalID, TA.TerminalIdentifier, TA.TerminalAssignmentCode, TA.TerminalAssignmentIsSuspended, 
										CRT.CarrierTypeName, LOWER(REPLACE(CRT.CarrierTypeName, ' ', '_')) AS CarrierTypeIconName, 
										C.CustomerName, 
										P.ProviderCode, 
										CONCAT_WS(', ', CR.CarrierRegistrationNumber, IF(TRIM(CR.CarrierName) = TRIM(CR.CarrierRegistrationNumber), NULL, CR.CarrierName)) AS CarrierCaption
						FROM			pnl_terminal AS T 
							LEFT JOIN	pnl_latestterminalassignment_by_terminal AS TA ON TA.TerminalID = T.TerminalID
							LEFT JOIN	pnl_customer AS C ON C.CustomerID = TA.CustomerID
							LEFT JOIN	pnl_provider AS P ON P.ProviderID = C.ProviderID
							LEFT JOIN	pnl_carrier AS CR ON CR.CarrierID = TA.CarrierID
							LEFT JOIN	pnl_carriertype AS CRT ON CRT.CarrierTypeID = CR.CarrierTypeID
						WHERE			(
											@UserGroupIdentifierHighest = 'ADMINISTRATOR' OR
											@UserID IN (SELECT CU.UserID FROM pnl_customeruser AS CU WHERE CU.UserID = @UserID AND CU.CustomerID = C.CustomerID) OR
											@UserID IN (SELECT CM.UserID FROM pnl_customermanagerterminal AS CMT LEFT JOIN pnl_customermanager AS CM ON CM.CustomerManagerID = CMT.CustomerManagerID WHERE CM.UserID = @UserID AND CMT.TerminalID = TA.TerminalID)
										)
							AND			(
											" . (count($TerminalID) ? "TA.TerminalID IN ({$TerminalIDList})" : "FALSE") . " OR # TerminalID
											" . (count($TerminalAssignmentCode) ? "TA.TerminalAssignmentCode IN ({$TerminalAssignmentCodeList})" : "FALSE") . " # TerminalAssignmentCode
										)
						;
		
					# Terminal data
						DROP TEMPORARY TABLE IF EXISTS tmp_terminaldata;
		
						CREATE TEMPORARY TABLE tmp_terminaldata (
							# Imported from TerminalData
								TerminalID BIGINT(20), 
								ID BIGINT(20) UNSIGNED, 
								Time DATETIME, 
								Latitude FLOAT(11, 5) NULL, 
								Longitude FLOAT(11, 5) NULL, 
								IsAccOn TINYINT(1) NULL, 
								VelocityKmH FLOAT(11, 3), 
								GeoLocationID BIGINT(20) NULL, 
								GeoLocationDistanceMeter FLOAT(14, 3) NULL, 
								INDEX (TerminalID), 
								INDEX (ID), 
								INDEX (Time), 
		
							# Calculated later
								DurationSecond INT(11) NULL, 
								DistanceMeter FLOAT(11, 3) NULL, 
								VelocityGPSKmH FLOAT(11, 3) NULL, 
								Bearing INT(3) NULL, 
								IsPitStopEnd TINYINT(1) NOT NULL DEFAULT 0, 
								INDEX (DurationSecond), 
								INDEX (DistanceMeter), 
								INDEX (VelocityGPSKmH), 
								INDEX (IsPitStopEnd)
						) ENGINE = MEMORY;
		
						# Panel: API: V2: TerminalData: Insert into temporary table ({$TerminalIDList})
						INSERT INTO		tmp_terminaldata (
											TerminalID, ID, Time, 
											Latitude, Longitude, 
											IsAccOn, VelocityKmH, 
											GeoLocationID, GeoLocationDistanceMeter
										)
						SELECT			TD.TerminalID, TD.TerminalDataID, TD.TerminalDataTime, 
										TD.TerminalDataLatitude, TD.TerminalDataLongitude, 
										TD.TerminalDataIsAccOn, TD.TerminalDataVelocity, 
										TD.GeoLocationPositionIDLandmark, TD.GeoLocationPositionLandmarkDistanceMeter
						FROM			pnl_terminaldata AS TD
							LEFT JOIN	tmp_terminal AS T ON T.ID = TD.TerminalID
						WHERE			T.ID IS NOT NULL
							AND			TD.TerminalDataTime BETWEEN @TerminalDataTimeFrom AND @TerminalDataTimeTo
							AND         (@VehicleRouteMode = 0 OR (
											# Basic filter for valid GPS data
											TD.TerminalDataIsGPSValid = 1 AND
											TD.TerminalDataLatitude IS NOT NULL AND	
											TD.TerminalDataLongitude IS NOT NULL

											# Logic fix: We cannot confidently filter Jitter correction here due to following reason
											# Filter for Jitter correction later after calculatign duration and distance between points
											# Do not depend on TerminalData for duration and distance as earlier data may come later
										))
						;
						
						DROP TEMPORARY TABLE IF EXISTS tmp_terminaldata2;
						
						CREATE TEMPORARY TABLE tmp_terminaldata2 (
							TerminalID BIGINT(20), 
							ID BIGINT(20) UNSIGNED, 
							Time DATETIME, 
							Latitude FLOAT(11, 5) NULL, 
							Longitude FLOAT(11, 5) NULL, 
							INDEX (TerminalID), 
							INDEX (ID), 
							INDEX (Time), 
							INDEX (Latitude), 
							INDEX (Longitude)
						) ENGINE = MEMORY;
						
						INSERT INTO		tmp_terminaldata2 (TerminalID, ID, Time, Latitude, Longitude) 
						SELECT			TD.TerminalID, TD.ID, TD.Time, TD.Latitude, TD.Longitude
						FROM			tmp_terminaldata AS TD;
						
						DROP TEMPORARY TABLE IF EXISTS tmp_terminaldata3;
						CREATE TEMPORARY TABLE tmp_terminaldata3 LIKE tmp_terminaldata2;
						INSERT INTO tmp_terminaldata3 SELECT TD.* FROM tmp_terminaldata2 AS TD;
		
						# Panel: API: V2: TerminalData: Calculate Duration and Distance ({$TerminalIDList})
						UPDATE			tmp_terminaldata AS TD
							LEFT JOIN	tmp_terminaldata2 AS TDP ON TDP.ID = (
											SELECT			TD3.ID
											FROM			tmp_terminaldata3 AS TD3
											WHERE			TD3.Time < TD.Time
												AND			TD3.TerminalID = TD.TerminalID
												AND			TD3.Latitude IS NOT NULL
												AND			TD3.Longitude IS NOT NULL
											ORDER BY		TD3.Time DESC
											LIMIT			1
										)
						SET				TD.DurationSecond = TIME_TO_SEC(TIMEDIFF(TD.Time, TDP.Time)), 
										TD.DistanceMeter = fnHaversineGreatCircleDistance(TDP.Latitude, TDP.Longitude, TD.Latitude, TD.Longitude)
						WHERE			TDP.ID IS NOT NULL;
		
						UPDATE			tmp_terminaldata AS TD
						SET				TD.VelocityGPSKmH = TD.DistanceMeter / 1000 / TD.DurationSecond * 60 * 60				
						WHERE			TD.DistanceMeter IS NOT NULL
							AND			TD.DurationSecond IS NOT NULL
						;

						# Panel: API: V2: TerminalData: Remove invalid data for route mode ({$TerminalIDList})
						DELETE FROM tmp_terminaldata WHERE (@VehicleRouteMode = 1 AND (
							# Filter out invalid/ignorable/scrap data
							VelocityGPSKmH > @MaximumConsiderableGPSVelocity OR
							DistanceMeter < @GPSJitterCorrectionMinimumDistance
						));

						TRUNCATE TABLE tmp_terminaldata2;
						TRUNCATE TABLE tmp_terminaldata3;
						
						INSERT INTO		tmp_terminaldata2 (TerminalID, ID, Time, Latitude, Longitude) 
						SELECT			TD.TerminalID, TD.ID, TD.Time, TD.Latitude, TD.Longitude
						FROM			tmp_terminaldata AS TD;
						
						INSERT INTO tmp_terminaldata3 SELECT TD.* FROM tmp_terminaldata2 AS TD;
		
						# Panel: API: V2: TerminalData: Recalculate Duration and Distance ({$TerminalIDList})
						UPDATE			tmp_terminaldata AS TD
							LEFT JOIN	tmp_terminaldata2 AS TDP ON TDP.ID = (
											SELECT			TD3.ID
											FROM			tmp_terminaldata3 AS TD3
											WHERE			TD3.Time < TD.Time
												AND			TD3.TerminalID = TD.TerminalID
												AND			TD3.Latitude IS NOT NULL
												AND			TD3.Longitude IS NOT NULL
											ORDER BY		TD3.Time DESC
											LIMIT			1
										)
						SET				TD.DurationSecond = TIME_TO_SEC(TIMEDIFF(TD.Time, TDP.Time)), 
										TD.DistanceMeter = fnHaversineGreatCircleDistance(TDP.Latitude, TDP.Longitude, TD.Latitude, TD.Longitude), 
										TD.Bearing = fnGeoBearing(TD.Longitude, TD.Latitude * (-1), TDP.Longitude, TDP.Latitude * (-1), 360) % 360
						WHERE			TDP.ID IS NOT NULL;
		
						UPDATE			tmp_terminaldata AS TD
						SET				TD.VelocityGPSKmH = TD.DistanceMeter / 1000 / TD.DurationSecond * 60 * 60
						WHERE			TD.DistanceMeter IS NOT NULL
							AND			TD.DurationSecond IS NOT NULL
						;

						UPDATE tmp_terminaldata AS TD SET TD.IsPitStopEnd = 1 WHERE TD.DurationSecond >= @MinimumPitStopDuration; # Detect pit stop end
		
						UPDATE			tmp_terminaldata AS TD
						SET				TD.DistanceMeter = 0, 
										TD.DurationSecond = 0, 
										TD.VelocityGPSKmH = 0, 
										TD.Bearing = 270
						WHERE			TD.DistanceMeter IS NULL;
		
						# Panel: API: V2: TerminalData: Get: Select TerminalData ({$TerminalIDList})
						SELECT			TD.*, 
										IF(TD.VelocityGPSKmH <= 2, 1, # Idle
											IF(TD.VelocityGPSKmH <= 15, 2, # Slow
												IF(TD.VelocityGPSKmH <= 60, 3, # Normal
													4 # Speeding
										))) AS MotionStateID
		
						FROM			tmp_terminaldata AS TD
							LEFT JOIN	tmp_terminaldata2 AS TDP ON TDP.ID = (
											SELECT			TD3.ID
											FROM			tmp_terminaldata3 AS TD3
											WHERE			TD3.Time < TD.Time
												AND			TD3.TerminalID = TD.TerminalID
											ORDER BY		TD3.Time DESC
											LIMIT			1
										)
						ORDER BY		TD.TerminalID ASC, TD.Time ASC;
		
					# Terminal data minutely summary
						DROP TEMPORARY TABLE IF EXISTS tmp_terminaldataminutely;
		
						CREATE TEMPORARY TABLE tmp_terminaldataminutely (
							TerminalID BIGINT(20), 
							DistanceKm FLOAT(11, 3), 
							INDEX (TerminalID)
						) ENGINE = MEMORY;
		
						INSERT INTO		tmp_terminaldataminutely (TerminalID, DistanceKm)
						SELECT			T.ID, 
										SUM(TDM.TerminalDataMinutelyDistanceMeter) / 1000 AS DistanceKm
						FROM			pnl_terminaldataminutely AS TDM
							LEFT JOIN	tmp_terminal AS T ON T.ID = TDM.TerminalID
						WHERE			T.ID IS NOT NULL
							AND			TDM.TerminalDataMinutelyTimeFirst >= @TerminalDataTimeFrom
							AND			TDM.TerminalDataMinutelyTimeLast <= @TerminalDataTimeTo
						GROUP BY		T.ID;
		
					# Geolocation
						SELECT			GL.GeoLocationPositionID AS ID, 
										GL.GeoLocationName AS Name, 
										GLP.GeoLocationPositionLatitude AS Latitude, 
										GLP.GeoLocationPositionLongitude AS Longitude
						FROM			pnl_geolocation AS GL
							LEFT JOIN	pnl_geolocationposition AS GLP ON GLP.GeoLocationPositionID = GL.GeoLocationPositionID
						WHERE			GL.GeoLocationPositionID IN (SELECT DISTINCT(TD.GeoLocationID) FROM tmp_terminaldata AS TD)
						ORDER BY		GL.GeoLocationPositionID ASC;
		
					# Terminal event > Prepare
						DROP TEMPORARY TABLE IF EXISTS tmp_terminalevent;
		
						CREATE TEMPORARY TABLE tmp_terminalevent(
							TerminalID BIGINT(20), 
							Time DATETIME, 
							TerminalEventID BIGINT(20) NULL, 
							TerminalGeoFenceAreaEventID BIGINT(20) NULL, 
							Latitude FLOAT(8, 5), 
							Longitude FLOAT(8, 5), 
							SubjectIdentifier VARCHAR(255),
							Subject VARCHAR(255),
							ActionIdentifier VARCHAR(255), 
							Action VARCHAR(255), 
							Comment VARCHAR(255), 
							NumericFactor FLOAT(7, 3) NULL, 
							INDEX (TerminalID), 
							INDEX (Time), 
							INDEX (SubjectIdentifier), 
							INDEX (ActionIdentifier), 
							
							# Calculated later
							TerminalDataID BIGINT(20) UNSIGNED NULL, 
							TimeAccOff DATETIME NULL, 
							INDEX (TerminalDataID)
						) ENGINE = MEMORY;
		
						# Terminal event
							INSERT INTO		tmp_terminalevent (
												TerminalEventID, TerminalID, Time, Latitude, Longitude, 
												SubjectIdentifier, Subject, 
												ActionIdentifier, Action, 
												NumericFactor, 
												Comment
											)
							SELECT			TE.TerminalEventID, TE.TerminalID, TE.TerminalEventTime, TE.TerminalEventLatitude, TE.TerminalEventLongitude, 
											TES.TerminalEventSubjectIdentifier, TES.TerminalEventSubjectName, 
											TEA.TerminalEventActionIdentifier, TEA.TerminalEventActionName, 
											TE.TerminalEventFactorNumeric, 
											NULL AS Comment
							FROM			pnl_terminalevent AS TE
								LEFT JOIN	pnl_terminaleventaction AS TEA ON TEA.TerminalEventActionID = TE.TerminalEventActionID
								LEFT JOIN	pnl_terminaleventsubject AS TES ON TES.TerminalEventSubjectID = TEA.TerminalEventSubjectID
							WHERE			TE.TerminalID IN (SELECT DISTINCT(T.ID) FROM tmp_terminal AS T)
								AND			TE.TerminalEventTime BETWEEN @TerminalDataTimeFrom AND @TerminalDataTimeTo
								AND			TE.TerminalEventLatitude IS NOT NULL
								AND			TE.TerminalEventLongitude IS NOT NULL
							;

						# GeoFence event
							INSERT INTO		tmp_terminalevent (
												TerminalGeoFenceAreaEventID, TerminalID, Time, Latitude, Longitude, 
												SubjectIdentifier, Subject, 
												Action, ActionIdentifier, 
												NumericFactor, 
												Comment
											)
							SELECT			TGFAE.TerminalGeoFenceAreaEventID, TGFAE.TerminalID, TGFAE.TerminalGeoFenceAreaEventTime, TGFAE.TerminalGeoFenceAreaEventLatitude, TGFAE.TerminalGeoFenceAreaEventLongitude, 
											@SubjectIdentifier := 'GEOFENCE' AS SubjectIdentifier, @Subject := 'GeoFence', 
											@Action := CONCAT_WS(' ', IF(TGFAE.GeoFenceAreaIDEntry IS NOT NULL, 'Entry', NULL), IF(TGFAE.GeoFenceAreaIDExit IS NOT NULL, 'Exit', NULL)) AS Action, 
											@ActionIdentifier := UPPER(@Action) AS ActionIdentifier, 
											NULL, 
											CONCAT_WS(', ', TGFAE.TerminalGeoFenceAreaEventLookupCaptionEntry, TGFAE.TerminalGeoFenceAreaEventLookupCaptionExit) AS Comment
							FROM			pnl_terminalgeofenceareaevent AS TGFAE
								#LEFT JOIN	pnl_geofencearea AS GFAEn ON GFAEn.GeoFenceAreaID = TGFAE.GeoFenceAreaIDEntry
								#LEFT JOIN	pnl_geofencearea AS GFAEx ON GFAEx.GeoFenceAreaID = TGFAE.GeoFenceAreaIDExit
							WHERE			TGFAE.TerminalID IN (SELECT DISTINCT(T.ID) FROM tmp_terminal AS T)
								AND			TGFAE.TerminalGeoFenceAreaEventTime BETWEEN @TerminalDataTimeFrom AND @TerminalDataTimeTo
								AND			TGFAE.TerminalGeoFenceAreaEventLatitude IS NOT NULL
								AND			TGFAE.TerminalGeoFenceAreaEventLongitude IS NOT NULL
							;

						# Detect TerminalDataID per event
							UPDATE		tmp_terminalevent AS TE
							SET			TE.TerminalDataID = (
											SELECT			TD.ID
											FROM			tmp_terminaldata AS TD
											WHERE			TD.TerminalID = TE.TerminalID AND
															TD.Time <= TE.Time
											ORDER BY		TD.Time DESC
											LIMIT			1
										);

						# Mirror Terminal event for previous time detection
							DROP TEMPORARY TABLE IF EXISTS tmp_terminalevent2;

							CREATE TEMPORARY TABLE tmp_terminalevent2 (
								TerminalID BIGINT(20), 
								Time DATETIME, 
								SubjectIdentifier VARCHAR(255),
								ActionIdentifier VARCHAR(255), 
								INDEX (TerminalID), 
								INDEX (Time), 
								INDEX (SubjectIdentifier), 
								INDEX (ActionIdentifier)
							) ENGINE = MEMORY;

							INSERT INTO tmp_terminalevent2 (TerminalID, Time, SubjectIdentifier, ActionIdentifier) 
							SELECT			TE.TerminalID, TE.Time, TE.SubjectIdentifier, TE.ActionIdentifier
							FROM			tmp_terminalevent AS TE;

						# Detect Engine stop time
							UPDATE			tmp_terminalevent AS TE
							SET				TE.TimeAccOff = (
												SELECT			TE2.Time
												FROM			tmp_terminalevent2 AS TE2
												WHERE			TE2.TerminalID = TE.TerminalID AND
																TE2.Time <= TE.Time AND 
																TE2.SubjectIdentifier = 'ACC' AND TE2.ActionIdentifier = 'OFF'
												ORDER BY		TE2.Time DESC
												LIMIT			1
											)
							WHERE			TE.SubjectIdentifier = 'ACC' AND TE.ActionIdentifier = 'ON';

					# Summary
						SELECT			T.*, 
										TDM.DistanceKm AS DistanceKmMinutely, 
										TDS.Earliest, 
										TDS.Latest, 
										TDS.Count, 
										TDS.DistanceMeter, 
										TDS.DurationSecond, 
										TDS.VelocityKmHMinimum, 
										TDS.VelocityKmHMaximum, 
										TDS.VelocityGPSKmHMinimum, 
										TDS.VelocityGPSKmHMaximum, 
										TDS.LatitudeMinimum, 
										TDS.LongitudeMinimum, 
										TDS.LatitudeMaximum, 
										TDS.LongitudeMaximum, 
										TDS.CenterLatitude, 
										TDS.CenterLongitude, 
										ROUND(((TDS.DistanceMeter / 1000) - TDM.DistanceKm) / TDM.DistanceKm * 100, 0) AS MinutelyDistanceDistortion, 
										COALESCE(TES.Count, 0) AS EventCount
						FROM			tmp_terminal AS T
							LEFT JOIN	tmp_terminaldataminutely AS TDM ON TDM.TerminalID = T.ID
							LEFT JOIN	(
											SELECT			TD.TerminalID, 
															@TerminalDataEarliest := MIN(TD.Time) AS Earliest, 
															@Latest := MAX(TD.Time) AS Latest, 
															COUNT(0) AS Count, 
															COALESCE(SUM(TD.DistanceMeter), 0) AS DistanceMeter, 
															COALESCE(SUM(TD.DurationSecond), 0) AS DurationSecond, 
															MIN(TD.VelocityKmH) AS VelocityKmHMinimum, 
															MAX(TD.VelocityKmH) AS VelocityKmHMaximum, 
															MIN(TD.VelocityGPSKmH) AS VelocityGPSKmHMinimum, 
															MAX(TD.VelocityGPSKmH) AS VelocityGPSKmHMaximum, 
															@LatitudeMinimum := MIN(TD.Latitude) AS LatitudeMinimum, 
															@LongitudeMinimum := MIN(TD.Longitude) AS LongitudeMinimum, 
															@LatitudeMaximum := MAX(TD.Latitude) AS LatitudeMaximum, 
															@LongitudeMaximum := MAX(TD.Longitude) AS LongitudeMaximum, 
															(@LatitudeMinimum + @LatitudeMaximum) / 2 AS CenterLatitude, 
															(@LongitudeMinimum + @LongitudeMaximum) / 2 AS CenterLongitude
											FROM			tmp_terminaldata AS TD
											GROUP BY		TD.TerminalID
										) AS TDS ON TDS.TerminalID = T.ID
							LEFT JOIN	(
											SELECT			TE.TerminalID, 
															COUNT(0) AS Count
											FROM			tmp_terminalevent AS TE
											GROUP BY		TE.TerminalID
										) AS TES ON TES.TerminalID = T.ID
						ORDER BY		T.ID ASC;
		
					# Status
						SELECT			@TerminalDataTimePeriodSecondNormal AS TerminalDataTimePeriodSecondNormal, 
										@TerminalDataTimePeriodSecondMaximum AS TerminalDataTimePeriodSecondMaximum, 
										@UserID AS UserID, 
										@UserGroupIdentifierHighest AS UserGroupIdentifierHighest, 
										@TerminalDataTimeFrom AS TerminalDataTimeFrom, 
										@TerminalDataTimeTo AS TerminalDataTimeTo, 
										@VehicleRouteMode AS VehicleRouteMode, 
										@MaximumConsiderableGPSVelocity AS MaximumConsiderableGPSVelocity, 
										@GPSJitterCorrectionMinimumDistance AS GPSJitterCorrectionMinimumDistance, 						
										@MinimumPitStopDuration AS MinimumPitStopDuration, 						
										@ProcessTimeBegin AS ProcessTimeBegin, 
										TIMEDIFF(NOW(), @ProcessTimeBegin) AS ProcessTimeDuration
						;
		
					# Terminal event > Show
						SELECT			TE.*, 
										TD.GeoLocationID, TD.GeoLocationDistanceMeter, 
										TIMEDIFF(TE.Time, TE.TimeAccOff) AS DurationTimeAccOff
						FROM			tmp_terminalevent AS TE 
							LEFT JOIN	tmp_terminaldata AS TD ON TD.ID = TE.TerminalDataID
						ORDER BY		TE.TerminalID ASC, TE.Time ASC;
						
					# Clean up
						DROP TEMPORARY TABLE tmp_terminaldata3;
						DROP TEMPORARY TABLE tmp_terminaldata2;
						DROP TEMPORARY TABLE tmp_terminaldata;
						DROP TEMPORARY TABLE tmp_terminaldataminutely;
						DROP TEMPORARY TABLE tmp_terminal;
						DROP TEMPORARY TABLE tmp_terminalevent2;
						DROP TEMPORARY TABLE tmp_terminalevent;
				"; 
				
				if($Debug)file_put_contents(__DIR__ . "/TerminalData-" . __FUNCTION__ . ".SQL", $SQL);
		
				$Recordset = $Database->Query($SQL);
				$Recordset = is_array($Recordset) ? $Recordset : [];
				$RecordsetCount = count($Recordset);
				#endregion Get data from database
		
				if($RecordsetCount >= 5){ // We have some data to deliver & cache
					$Response["Response"]["MotionState"] = $Recordset[0];
					$Response["Response"]["Data"] = $Recordset[1];
					$Response["Response"]["GeoLocation"] = $Recordset[2];
					$Response["Response"]["Terminal"] = $Recordset[3];
					$Response["Response"]["Status"] = $Recordset[4][0];
					$Response["Response"]["Event"] = isset($Recordset[5]) ? $Recordset[5] : [];
					
					$Response = json_encode($Response);
					file_put_contents($CacheFile, $Response); // Create cache file
				}else{ // Error: No data
					$Response["Error"]["Code"] = $this::ERROR_DATABASE_DATA_INSUFFICIENT;
					$Response["Error"]["Description"] = "Insufficient data";
						
					$Response = json_encode($Response);
				}
			}else{ // Deliver from cache
				$Response = file_get_contents($CacheFile); // This is already JSON encoded
				//file_put_contents(__DIR__ . "/cache-UserID-{$UserID}.json", $Response);
			}
		}else{ // Error: Missing arguments, no processing took place, no cache delivered
			$Response["Error"]["Code"] = $this::ERROR_MISSING_ARGUMENT;
			$Response["Error"]["Description"] = "Missing argument";
					
			$Response = json_encode($Response);
		}

		return $Response;
	}
	#endregion Method

	#region Property
	public function User($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}

	public function Database($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}

	public function Debug($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}

	public function MaximumConsiderableGPSVelocity($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}

	public function GPSJitterCorrectionMinimumDistance($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}

	public function MinimumPitStopDuration($Value = null){
		if(is_null($Value))return $this->Property[__FUNCTION__];
		$this->Property[__FUNCTION__] = $Value;
	}
	#endregion Property
}
?>