<?php
namespace sPHP;

class xNavigation extends Basic{
	public function __construct(?string $ID, ?array $Children, ?string $IconBaseURL, ?string $CSSSelector, ?bool $AutoCollapse){
		parent::{__FUNCTION__}([ // Set initial property values upon object instantiation
			"ID"			=>	$ID, 
			"Children"		=>	is_null($Children) ? [] : $Children, 
			"IconBaseURL"	=>	$IconBaseURL, 
			"CSSSelector"	=>	$CSSSelector, 
			"AutoCollapse"	=>	is_null($AutoCollapse) ? false : $AutoCollapse, 
		]);

		#region Property dependancy
		//* Add properties that will reset other properties when set/changed
		parent::AddPropertyDependancy("ID", ["HTML", ]);
		parent::AddPropertyDependancy("Children", ["HTML", ]);
		parent::AddPropertyDependancy("IconBaseURL", ["HTML", ]);
		parent::AddPropertyDependancy("CSSSelector", ["HTML", ]);
		parent::AddPropertyDependancy("AutoCollapse", ["HTML", ]);
		//parent::AddPropertyDependancy("LastName", ["Name", "Caption", ]); //? Name & Caption will be reset when LastName changes
		#endregion Property dependancy
	}
	
	public function __destruct(){
		parent::{__FUNCTION__}();
	}

	public function HTML(){ //DebugDump("Create HTML for xNavigation");
		if(is_null($this->Property[__FUNCTION__])){
			$PadHTML = [];

			if(!is_null($this->Property["Children"]))foreach($this->Property["Children"] as $PadIndex => $Pad){
				if($Pad->ID)$Pad->ID = "{$this->Property["ID"]}-{$Pad->ID}";
				if(!$Pad->IconBaseURL)$Pad->IconBaseURL = $this->Property["IconBaseURL"];

				$Pad->AutoCollapse = $this->Property["AutoCollapse"];
				$Pad->ParentID = $this->Property["ID"];
				$Pad->Selected = !$PadIndex;

				$PadHTML[] = $Pad->HTML;
			}

			$this->Property[__FUNCTION__] = count($PadHTML) ? "<nav class=\"xNavigation" . ($this->Property["CSSSelector"] ? " {$this->Property["CSSSelector"]}" : null) . "\">" . implode("", $PadHTML) . "</nav>" : null;
		}

		return $this->Property[__FUNCTION__];
	}
}

class xPad extends Basic{
	public function __construct(?string $ID, ?string $Caption, ?string $URL, ?string $OnClick, ?array $Children, ?string $Icon, ?string $IconBaseURL){
		parent::{__FUNCTION__}([ // Set initial property values upon object instantiation
			"ID"			=>	$ID, 
			"Caption"		=>	$Caption, 
			"URL"			=>	$URL, 
			"OnClick"		=>	$OnClick, 
			"Children"		=>	is_null($Children) ? [] : $Children, 
			"Icon"			=>	$Icon, 
			"IconBaseURL"	=>	$IconBaseURL, 
		]);

		#region Property dependancy
		//* Add properties that will reset other properties when set/changed
		parent::AddPropertyDependancy("ID", ["HTML", ]);
		parent::AddPropertyDependancy("Caption", ["HTML", ]);
		parent::AddPropertyDependancy("URL", ["HTML", ]);
		parent::AddPropertyDependancy("Children", ["HTML", ]);
		//parent::AddPropertyDependancy("LastName", ["Name", "Caption", ]); //? Name & Caption will be reset when LastName changes
		#endregion Property dependancy
	}
	
	public function __destruct(){
		parent::{__FUNCTION__}();
	}

	public function HTML(){
		if(is_null($this->Property[__FUNCTION__])){ //DebugDump("Create HTML for xPad(" . ($this->Property["ID"] ? $this->Property["ID"] : $this->Property["Caption"]) . ")");
			if($this->Property["Caption"] == ""){
				$this->Property[__FUNCTION__] = "<div class=\"Separator\"></div>";
			}
			else{				
				$ChildPadHTML = [];
	
				if(!is_null($this->Property["Children"]))foreach($this->Property["Children"] as $ChildPadIndex => $ChildPad){
					if($ChildPad->ID)$ChildPad->ID = "{$this->Property["ID"]}-{$ChildPad->ID}";
					if(!$ChildPad->IconBaseURL)$ChildPad->IconBaseURL = $this->Property["IconBaseURL"];
					
					$ChildPad->AutoCollapse = $this->Property["AutoCollapse"];
					$ChildPad->ParentID = $this->Property["ID"];
					$ChildPad->Selected = !$ChildPadIndex;
	
					$ChildPadHTML[] = $ChildPad->HTML;
				}
	
				$ChildPadCount = count($ChildPadHTML);
				$ChildrenSwitchID = "xNavigationChildrenSwitch-{$this->Property["ID"]}";
				$CaptionTitleHTML = "<img src=\"{$this->Property["IconBaseURL"]}{$this->Property["Icon"]}\" alt=\"Icon\" class=\"Icon\"><span class=\"Title\">{$this->Property["Caption"]}</span>" . ($ChildPadCount ? "<span class=\"ExpansionMarker\"></span>" : null) . "";
				$CaptionHTML = $ChildPadCount ? "<label for=\"{$ChildrenSwitchID}\" class=\"Caption\">{$CaptionTitleHTML}</label>" : ($this->Property["URL"] ? "<a href=\"{$this->Property["URL"]}\" class=\"Caption\">{$CaptionTitleHTML}</a>" : "<span onclick=\"{$this->Property["OnClick"]}\" class=\"Caption\">{$CaptionTitleHTML}</span>");
				$SwitchSelectedHTML = $this->Property["Selected"] ? " checked" : null;
	
				$this->Property[__FUNCTION__] = "
					" . ($ChildPadCount ? ($this->Property["ParentID"] && $this->Property["AutoCollapse"] ? "<input id=\"{$ChildrenSwitchID}\" name=\"{$this->Property["ParentID"]}\" type=\"radio\"{$SwitchSelectedHTML} class=\"ChildrenSwitch\">" : "<input id=\"{$ChildrenSwitchID}\" type=\"checkbox\"{$SwitchSelectedHTML} class=\"ChildrenSwitch\">") : null) . "
					<div class=\"Pad\">
						{$CaptionHTML}
						" . ($ChildPadCount ? ("<div class=\"Children\">" . implode("", $ChildPadHTML) . "</div>") : null) . "
					</div>
				";
			}
		}

		return $this->Property[__FUNCTION__];
	}
}

$xNavigation = new xNavigation("xNavigation", [
	new xPad($ID = "Food", $ID, null, null, [
		new xPad(null, "Breakfast", "#", null, null, "logo.png", null), 
		new xPad($ID = "Meal", $ID, null, null, [
			new xPad($ID = "Lunch", $ID, null, null, [
				new xPad(null, "Light", "#", null, null, "logo.png", null), 
				new xPad(null, "Heavy", "#", null, null, "logo.png", null), 
			], "logo.png", null), 
			new xPad($ID = "Dinner", $ID, null, null, [
				new xPad(null, "Asian", "#", null, null, "logo.png", null), 
				new xPad(null, "Chinese", "#", null, null, "logo.png", null), 
				new xPad(null, "Thai", "#", null, null, "logo.png", null), 
			], "logo.png", null), 
		], "logo.png", null), 
		new xPad(null, "Other", "#", null, null, "logo.png", null), 
	], "logo.png", null), 
	new xPad(null, "Direct item", "#", null, null, "logo.png", null), 
	new xPad($ID = "Help", $ID, null, null, [
		new xPad(null, "Topic", "#", null, null, "logo.png", null), 
		new xPad(null, "Check for update", "#", null, null, "logo.png", null), 
		new xPad(null, "", null, null, null, null, null), 
		new xPad(null, "About", null, "alert('Want to know more about us?');", null, "logo.png", null), 
	], "logo.png", null), 
], "./image/", "-xNavigationAccordion -xNavigationHorizontal", null);
?><div class="Content">
	<h1>Font test</h1>

	<div style="font-family: 'Trebuchet MS';">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Trebuchet MS</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: Consolas;">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Consolas</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: Roboto;">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Roboto</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: Tahoma;">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Tahoma</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: 'Courier New';">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Courier New</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: Arial;">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Arial</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<div style="font-family: Verdana;">
		<div style="position: absolute; right: 0; border-radius: 5px; background-color: Black; padding: 0 0.5em; color: White; font-family: Consolas; font-weight: bold;">Verdana</div>
		<div style="text-transform: uppercase;">a quick brown fox jumps over the lazy dog</div>
		<div style="display: none;">a quick brown fox jumps over the lazy dog</div>
	</div>

	<hr><br>

	<style>
		/* Basic */
		.xNavigation{width: 15em;}
		.xNavigation .ChildrenSwitch{display: none;}
		.xNavigation .Pad:last-child > .Caption{border-bottom: 1px Black solid;}
		.xNavigation .ChildrenSwitch + .Pad > .Caption{border-color: Green; background-color: Green; color: White;}
		.xNavigation .Pad > .Caption{display: block; border: 1px Black solid; border-bottom-width: 0; padding: 0.25em 0.5em; color: inherit; cursor: pointer;}
		.xNavigation .Pad > .Caption:hover{background-color: Blue; color: White; text-decoration: none;}
		.xNavigation .Pad > .Caption > .Icon{position: absolute; left: 0.5em; top: 0.5em; width: 1em; height: 1em;}
		.xNavigation .Pad > .Caption > .Title{margin-left: 1.5em; margin-right: 1.5em;}
		.xNavigation .Pad > .Caption > .ExpansionMarker{position: absolute; right: 0.25em; bottom: 0; padding: 0.25em 0.5em;}
		.xNavigation .Pad > .Caption > .ExpansionMarker:before{content: '▼';}
		.xNavigation .Pad > .Children{margin-left: 1em; max-height: 0; opacity: 0; overflow: hidden; transition: all 0.25s ease;}
		.xNavigation .Separator{width: 100%; height: 1px; background-color: Black;}
		
		.xNavigation .ChildrenSwitch:checked + .Pad > .Caption{border-color: Navy; background-color: Navy; color: White;}
		.xNavigation .ChildrenSwitch:checked + .Pad > .Caption > .ExpansionMarker:before{content: '△';}
		.xNavigation .ChildrenSwitch:checked + .Pad > .Caption + .Children{max-height: 99999px; opacity: 100%;}

		/* Accordion */
		.xNavigationAccordion .Pad > .Caption{border-width: 0 !important;}
		.xNavigationAccordion .Pad > .Children{margin-left: 0;}

		/* Horizontal */
		.xNavigationHorizontal{width: auto; background-color: Navy;}
		.xNavigationHorizontal > .Pad{float: left;}
		.xNavigationHorizontal .Pad > .Caption{border-width: 0; background-color: transparent !important; white-space: nowrap;}
		.xNavigationHorizontal > .Pad > .Children .Pad > .Caption{color: Black;}
		.xNavigationHorizontal .ChildrenSwitch + .Pad > .Caption{cursor: default;}
		.xNavigationHorizontal .Pad > .Caption:hover{background-color: Blue !important; color: White !important;}
		.xNavigationHorizontal .Pad > .Caption > .ExpansionMarker:before{content: '▶' !important;}
		.xNavigationHorizontal > .Pad > .Caption{color: White;}
		.xNavigationHorizontal > .Pad > .Caption > .ExpansionMarker{display: none;}
		.xNavigationHorizontal .Pad > .Children{display: none; position: absolute; top: -1px; right: -6em; max-height: none !important; margin: 0; box-shadow: 2.5px 2.5px 2.5px 0 Grey; border: 1px Black solid; background-color: White; opacity: 100% !important; overflow: visible; z-index: 1;}
		.xNavigationHorizontal > .Pad > .Children{left: 1em; top: auto;}
		.xNavigationHorizontal .Pad:hover > .Children{display: block;}
		.xNavigationHorizontal > .Separator{display: none;}
		.xNavigationHorizontal:after{display: block; clear: both; content: '';}
	</style>

	<?=$xNavigation->HTML?>

	<hr><br><br><br><br><br>

	<p>
		Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet 
		Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet 
		Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet Lorem Ipsum Doler Site Amet 
	</p>

	<form>
		<label>First name <input type="text" name="FirstName"></label>
		<button type="submit">Submit form</button>
	</form>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>
	
	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>
	
	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>
	
	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>
	
	<p>
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
		Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet Lorem Ipsum Doler Sit Amet 
	</p>

	Bottom line
</div>
