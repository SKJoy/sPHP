<?php
namespace sPHP;

$APP->DocumentType(DOCUMENT_TYPE_JSON);
$NumberColumn = $TBL[$_POST["Entity"]]->Structure()["Number"];

foreach(ListToArray(SetVariable("Column", "{$_POST["Entity"]}Name")) as $Column){
	$WHERE = ["" . (strpos($Column, ".") ? null : "{$TBL[$_POST["Entity"]]->Alias()}.") . "{$Column} "];
	$Keyword = SetVariable("__Keyword");

	if(in_array($Column, $NumberColumn)){
		$WHERE[] = "= " . floatval($Keyword) . "";
	}
	else{
		if(isset($_POST["__Exact"])){
			$WHERE[] = "= '{$DTB->Escape($Keyword)}'";
		}
		else{
			$WHERE[] = "LIKE '%{$DTB->Escape($Keyword)}%'";
		}
	}

	//$WHERE[] = in_array($Column, $NumberColumn) ? "= " . floatval($Keyword) . "" : (SetVariable("__Partial") ? "LIKE '%{$DTB->Escape($Keyword)}%'" : "= '{$DTB->Escape($Keyword)}'");

	$WHEREClause[] = implode("", $WHERE);
} //var_dump($WHEREClause); exit;

$ANDWHEREClause = [];

if($_POST["Entity"] == "User"){
	if(trim(SetVariable("UserGroupIdentifierList")))$ANDWHEREClause[] = "
		U.UserID IN (
			SELECT			UUG.UserID 
			FROM			sphp_userusergroup AS UUG
			WHERE			UUG.UserUserGroupIsActive = 1 
				AND			UUG.UserGroupID IN (
								SELECT			UG.UserGroupID
								FROM			sphp_usergroup AS UG 
								WHERE			UG.UserGroupIdentifier IN ('" . implode("', '", array_filter(explode(",", str_replace(" ", "", $_POST["UserGroupIdentifierList"])))) . "')
							)
		)
	";
}
else{

}

print json_encode($TBL[$_POST["Entity"]]->Get(isset($WHEREClause) ? ("(" . implode(" OR ", $WHEREClause) . ") AND " . (count($ANDWHEREClause) ? implode(" AND ", $ANDWHEREClause) : "TRUE") . "") : "FALSE"));
?>