<?php
//* Copy this script as 'index.php' to make your own
namespace sPHP; // Use framework namespace for shortcut to constants

#region Reusable shortcut variable
$Name = "Stupid Application";
$ShortName = "sApp";
$Domain = $_SERVER["SERVER_NAME"];

$LocalHost = "x127.0.0.1, x::1, xLocalHost, x192.168.1.1, x192.168.1.10, x192.168.137.1";
$DatabaseUser = null;
#endregion Reusable shortcut variable

$Configuration = [
	// System
	"AdministratorEmail"			=>	"Administrator@System.Dom",
	"AdministratorPasswordHash"		=>	"5f4dcc3b5aa765d61d8327deb882cf99", // Default for 'password'; Use  https://www.md5hashgenerator.com/
	"AdministratorName"				=>	"System Administrator",

	"CompanyName"					=>	"Binary Men",
	"CompanyAddress"				=>	"Dhaka, Bangladesh",
	"CompanyPhone"					=>	"+8801552601833",
	"CompanyEmail"					=>	"Info@{$Domain}",
	"CompanyURL"					=>	"{$Environment->URL()}",

	"Name"							=>	"{$Name}",
	"ShortName"						=>	"{$ShortName}",
	"Title"							=>	"",
	"TitlePrefix"					=>	"{$Name}",
	"TitleSuffix"					=>	"",
	"TitleSeperator"				=>	": ",
	"Icon"							=>	"favicon",
	"ThemeColor"					=>	"#FB404B", 
	"BackgroundColor"				=>	"#FB404B", 

	"Description"					=>	"{$Name} application",
	"Keyword"						=>	"{$Name}, {$ShortName}, Application",

	"DateFormat"					=>	"D, M j, Y",
	"ShortDateFormat"				=>	"M j, Y",
	"LongDateFormat"				=>	"l, F j, Y",
	"TimeFormat"					=>	"H:i:s",

	"DatabaseType"					=>	null, //DATABASE_TYPE_MYSQL | DATABASE_TYPE_MSSQL
	"DatabaseHost"					=>	null, //"127.0.0.1",
	"DatabaseUser"					=>	"{$DatabaseUser}",
	"DatabasePassword"				=>	"password",
	"DatabaseName"					=>	"{$DatabaseUser}",
	"DatabaseODBCDriver"			=>	"SQL Server Native Client 11.0",
	"DatabaseTablePrefix"			=>	"sphp_",
	"DatabaseTimezone"				=>	"+06:00", // Using named timezone is unstable in some cases
	"DatabaseStrictMode"			=>	true,
	"DatabaseLogTraffic"			=>	true,
	"DatabaseUserAuthentication"	=>	false,

	"DatabaseTable"					=>	[ // Defaine database tables for automatic preset operations
											"" . ($Entity = "API") . "Authorization" => new Database\Table("{$Entity} authorization"),
											"" . ($Entity = "API") . "AuthorizationRestrictionIP" => new Database\Table("{$Entity} authorization restriction by IP"),
											"" . ($Entity = "API") . "AuthorizationToken" => new Database\Table("{$Entity} authorization token"),
											"" . ($Entity = "API") . "AuthorizationTokenActivity" => new Database\Table("{$Entity} authorization token activity"),

											"" . ($Entity = "Religion") . "" => new Database\Table("{$Entity}"),
											"" . ($Entity = "Blood") . "Group" => new Database\Table("{$Entity} group"),
											"" . ($Entity = "Notification") . "Type" => new Database\Table("{$Entity} type"),
											"" . ($Entity = "Notification") . "Source" => new Database\Table("{$Entity} source"),
											"" . ($Entity = "Notification") . "" => new Database\Table("{$Entity}"),
											"" . ($Entity = "Application") . "ChangeLog" => new Database\Table("{$Entity} change log"),
											"" . ($Entity = "Data") . "Type" => new Database\Table("{$Entity} type"),
											"" . ($Entity = "Currency") . "" => new Database\Table("{$Entity}"),
											"" . ($Entity = "Payment") . "Method" => new Database\Table("{$Entity} method"),
											"" . ($Entity = "Payment") . "Type" => new Database\Table("{$Entity}"),
											"" . ($Entity = "OTP") . "" => new Database\Table("{$Entity}"),

											"" . ($Entity = "User") . "FCN" => new Database\Table("{$Entity} FCM", "CRMC", null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "MaintenanceCategory" => new Database\Table("{$Entity} maintenance category", "CRMC", null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "Maintenance" => new Database\Table("{$Entity} maintenance", "CRM", null, null, null, null, "pnl_"),
											"" . ($Entity = "Person") . "Relation" => new Database\Table("{$Entity} relation", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Employment") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Educational") . "Qualification" => new Database\Table("{$Entity} qualification", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "License") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Duty") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Provider") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Customer") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Customer") . "User" => new Database\Table("{$Entity} user", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Customer") . "Manager" => new Database\Table("{$Entity} manager", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Customer") . "ManagerTerminal" => new Database\Table("{$Entity} manager terminal", null, null, null, null, null, "pnl_"),

											"" . ($Entity = "GeoFence") . "Group" => new Database\Table("{$Entity} group", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "GeoFence") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "GeoFence") . "Area" => new Database\Table("{$Entity} area", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "GeoFence") . "Terminal" => new Database\Table("{$Entity} terminal", null, null, null, null, null, "pnl_"),

											"" . ($Entity = "Terminal") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "GeoFenceAreaEvent" => new Database\Table("{$Entity} geofence area event", null, null, null, null, null, "pnl_"),

											"" . ($Entity = "Route") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Fuel") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "Type" => new Database\Table("{$Entity} type", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "Group" => new Database\Table("{$Entity} group", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "" => new Database\Table("{$Entity}", "CR", null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "UsageLimit" => new Database\Table("{$Entity} usage limit", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Carrier") . "Fuel" => new Database\Table("{$Entity} fuel", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Operator") . "Group" => new Database\Table("{$Entity} group", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Operator") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Operator") . "Assignment" => new Database\Table("{$Entity} assignment", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "Information" => new Database\Table("{$Entity} information", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "Data" => new Database\Table("{$Entity} data", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Site") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "EventSubject" => new Database\Table("{$Entity} event subject", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "EventAction" => new Database\Table("{$Entity} event action", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "Event" => new Database\Table("{$Entity} event", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "CommandSubject" => new Database\Table("{$Entity} command subject", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "CommandAction" => new Database\Table("{$Entity} command action", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Terminal") . "Command" => new Database\Table("{$Entity} command", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Load") . "Event" => new Database\Table("{$Entity} event", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Message") . "" => new Database\Table("{$Entity}", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Parking") . "" => new Database\Table("{$Entity}", "PK", null, null, null, null, "pnl_"),

											"" . ($Entity = "Support") . "Request" => new Database\Table("{$Entity} request", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Support") . "RequestCategory" => new Database\Table("{$Entity} request category", null, null, null, null, null, "pnl_"),
											"" . ($Entity = "Support") . "RequestResponse" => new Database\Table("{$Entity} request response", null, null, null, null, null, "pnl_"),
										],

	"FieldCaptionWidth"				=>	190,
	"FieldCaptionInlineWidth"		=>	190,
	"FieldContentWidth"				=>	null,
	"FieldContentInlineWidth"		=>	null,
	"FieldContentFullWidth"			=>	750,
	"InputWidth"					=>	265,
	"InputInlineWidth"				=>	265,
	"InputFullWidth"				=>	750,
	"InputDateWidth"				=>	168,
	"InputTimeWidth"				=>	116,
	"TextareaHeight"				=>	75,
	"DatagridRowsPerPage"			=>	50,

	"ThumbnailMaximumDimension"		=>	64,

	"TinyMCETextareaTheme"			=>	"advanced", // advanced, simple
	"TinyMCETextareaSkin"			=>	"o2k7", // o2k7, default, highcontrast

	"Stylesheet"					=>	[ // Array for multiple style sheets
											//"{$Environment->URL()}style/3rdparty/bootstrap/bootstrap.min.css",
											//"{$Environment->URL()}style/3rdparty/bootstrap/bootstrap-table.css",
											//"{$Environment->URL()}style/3rdparty/font-awesome.min.css",
											//"{$Environment->URL()}javascript/3rdparty/w2ui/w2ui-1.5.rc1.css",
											"{$Environment->URL()}style/3rdparty/chartjs/Chart.min.css",
											"{$Environment->URL()}style/loader.css",
										],

	"JavaScript"					=>	[ // Array for multiple JavaScripts
											"{$Environment->URL()}javascript/3rdparty/tinymce/tiny_mce.js",
											//"https://maps.googleapis.com/maps/api/js?key=GoogleMapsAPIKey&libraries=drawing,geometry,places",
											//"{$Environment->URL()}javascript/3rdparty/markerAnimate.js",
											//"{$Environment->URL()}javascript/3rdparty/chartjs/Chart.min.js",
											//"{$Environment->URL()}javascript/3rdparty/chartjs/chartjs-plugin-datalabels.js",
											//"{$Environment->URL()}javascript/3rdparty/jquery-3.5.0.min.js",
											//"{$Environment->URL()}javascript/3rdparty/md5.js",
											//"{$Environment->URL()}javascript/3rdparty/w2ui/w2ui-1.5.rc1.js",
											//"{$Environment->URL()}javascript/3rdparty/popper.min.js",
											//"{$Environment->URL()}javascript/3rdparty/moment.min.js",
											//"{$Environment->URL()}javascript/3rdparty/bootstrap/bootstrap.min.js",
											//"{$Environment->URL()}javascript/3rdparty/bootstrap/bootstrap-table.js",
											//"{$Environment->URL()}javascript/library/dhtml.js",
											//"{$Environment->URL()}javascript/library/dom.js",
											"{$Environment->URL()}javascript/tinymce-custom.js",
											"{$Environment->URL()}javascript/sjs.js",
											"{$Environment->URL()}javascript/main.js",
										],

	"HTMLHeadCode"					=>	"
											<!-- BEGIN: HTML/JavaScript for the head section -->
											<!-- END: HTML/JavaScript for the head section -->
										",

	"EncryptionKey"					=>	"{$Name} for {$_SERVER["SERVER_NAME"]}",
	"UseSystemScript"				=>	true,
	"CronNotificationInterval"		=>	5, // Notification batch send out interval in seconds
	"CronMaximumExecutionTime"		=>	60 * 60, // Maximum execution & resume time for Application cron in seconds
	"SendNotification"				=>	true, // Use Email and SMS notification
	
	"UserDeviceNotification"		=>	false, // Use browser notification
	"UserSignInNotification"		=>	true, // Notification on User sign in for ADMINISTRATOR 

	"SMTPBodyStyle"					=>	"",
	"SMTPHost"						=>	null,
	"SMTPPort"						=>	null,
	"SMTPUser"						=>	null,
	"SMTPPassword"					=>	null,

	"ContentEditMode"				=>	false,
	"ContentEditModeServer"			=>	$LocalHost,
	"ContentEditModeClient"			=>	$LocalHost,

	"CustomError"					=>	true,
	"DebugMode"						=>	false,
	"DebugModeServer"				=>	$LocalHost,
	"DebugModeClient"				=>	$LocalHost,

	"SessionName"					=>	"{$Name}@{$Domain}",
	"SessionLifetime"				=>	20 * 60, // In seconds
	"SessionIsolate"				=>	true,
	"SessionIgnoreScript"			=>	[ // Allow specific scripts to be ignored with session activity/last time
											//"API/V2/Entry", 
										], 

	"Viewport"						=>	"width=device-width, initial-scale=1.0",

	"LanguageName"					=>	"English (United States)",
	"LanguageCode"					=>	"EN",
	"LanguageRegionCode"			=>	"US",
	"LanguageNativeName"			=>	"English (United States)",
	"LanguageNativelyName"			=>	"English (United States)", // Name in native alphabet

	"GuestEmail"					=>	"Guest@{$Domain}",
	"GuestName"						=>	"Guest Visitor",

	"TemplateCacheLifetime"			=>	5 * 60, // In seconds
	"TemplateCacheActionMarker"		=>	"#",

	"Timezone"						=>	"Asia/Dhaka",
	"DocumentType"					=>	DOCUMENT_TYPE_HTML,
	"DefaultScript"					=>	"Home",
	"CharacterSet"					=>	CHARACTER_SET_UTF8,
	"StatusCode"					=>	HTTP_STATUS_CODE_OK,
	"IFrameLoad"					=>	IFRAME_LOAD_SAMEORIGIN, // IFRAME_LOAD_ALLOW | IFRAME_LOAD_DENY | IFRAME_LOAD_SAMEORIGIN

	"VersionMajor"					=>	1,
	"VersionMinor"					=>	0,
	"VersionRevision"				=>	0,

	// Other
	"SearchInputPrefix"				=>	"Search_",
	"SMSHTTPAPIURL"					=>	"http://bondstein.info/smsServer/entry.php?panel=%Source%&mobile=%PhoneNumber%&text=%Message%&reason=%Purpose%&priority=9&schedule=&token=1&ts=1",

	// Custom
	"RepositoryURL"					=>	"https://github.com/SKJoy/sPHP", 
	"FacebookURL"					=>	"https://www.facebook.com/stupidPHP", 
	"MaxMindGeoLiteCityDatabaseURL"	=>	"{$Environment->UploadURL()}MaxMindGeoLiteCityDatabase.zip", 
];
?>