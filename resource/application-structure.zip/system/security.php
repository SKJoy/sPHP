<?php
//* Copy this script as 'index.php' to make your own
namespace sPHP;
// TODO: Make the system go back to the original location after authentication where the user intends to be
$_POST["_Script"] = $SSN->IsGuest() ? ( // Guest
	in_array(strtolower($_POST["_Script"]), explode(",", str_replace(" ", "", strtolower("Test/Object/HTML/UI/Menubar, API/System/V2/Gateway, Cron/Application, User/SignIn, User/SignInAction, User/SignUp, User/SignUpAction, User/Password/Reset, Test, FAQ, Contact, Home")))) ? $_POST["_Script"] : // Permitted
	$APP->DefaultScript() // Denied
) : $_POST["_Script"]; // Permitted for authenticated user
?>