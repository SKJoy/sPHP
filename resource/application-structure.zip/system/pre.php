<?php
namespace sPHP;

require __DIR__ . "/../library/function.php"; // Load library functions
require __DIR__ . "/security.php"; // Check if script execution is to be allowed
?>