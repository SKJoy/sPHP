<?php
namespace sPHP;

?>