# VMS: Vehicle Management System
General purpose vehicle management system
## Requirement
* PHP 8
* MySQL/MariaDB
* sPHP framework
## Installation
* Upload/place/clone the application code on web server;
* Rename '/-index.php' to '/index.php';
* Modify '/index.php' for correct sPHP link up;
* Navigate to the application URL to let the system create required application structure
* Configure the application with '/system/configuration.php';
