</main>

<footer>
	<div class="Content">				
		<div class="General">SOME FOOTER CONTENT GOES HERE TOO</div>

		<nav class="Navigation">
			<a href="#" class="Item">Features</a>
			<a href="#" class="Item">Mechanism</a>
			<a href="#" class="Item">How to</a>
			<a href="#" class="Item">Reference</a>
			<a href="#" class="Item">Download</a>
			<a href="#" class="Item">Contact</a>
		</nav>
	</div>
</footer>

<div class="RightPanel">
	RIGHT PANEL
</div>

<div class="BottomPanel">
	<div class="Content">				
		<div class="Left">&copy;2021 <a href="#" class="Company" onclick="alert('TODO: Navigate to contact us page.');">Company Limited</a>, all rights reserved.</div>

		<nav class="Navigation">
			<a href="" class="Item">About</a>
			<a href="" class="Item">Contact</a>
			<a href="" class="Item">Terms of service</a>
		</nav>
	</div>
</div>

<a href="#DocumentBody" title="Go to top" class="DocumentLocationAnchorTop">▲</a>

<div id="DocumentAlertCookiePolicy">
	<p><span class="Strong">Privacy</span>: We use cookies to improve user experience and analyze website traffic. By clicking “Accept“, you agree to our website's cookie use as described in our <a href="#">Cookie Policy</a>.</p>
	<button type="button" onclick="sJS.HTTP.Cookie('CookiePolicyAccepted', true, 1); document.body.removeChild(this.parentElement);">Accept</button>
	<button type="button" onclick="alert('We are trying to send you back from where you came to this site. Please note that you need to accept our cookie policy in order to proceed with this site.'); history.back();">Deny</button>
</div>

<script>
	document.getElementById('DocumentAlternateTheme').checked = sJS.HTTP.Cookie('AlternateTheme') == 'true'; // Restore last alternate theme state
	document.getElementById('LeftPanelToggleSwitch').checked = sJS.HTTP.Cookie('LeftPanel') == 'true'; // Restore last left panel state

	if(sJS.HTTP.Cookie('CookiePolicyAccepted') == 'true')document.body.removeChild(document.getElementById('DocumentAlertCookiePolicy')); // Remove cookie policy alert if already accepted
</script>