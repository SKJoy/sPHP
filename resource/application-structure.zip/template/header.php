<?php
namespace sPHP;

$LeftPanelNavigationMenubarKey = "LeftPanelNavigation";
SetVariable("Menubar-{$LeftPanelNavigationMenubarKey}-Home", true); // Default selected item

$LeftPanelNavigation = new HTML\UI\Menubar($LeftPanelNavigationMenubarKey, [
	new HTML\UI\Menubar\Pad($PadKey = "Home", new HTML\UI\Menubar\Pad\Item(null, $APP->URL("Home", "Menubar-{$LeftPanelNavigationMenubarKey}-{$PadKey}"), "home.png", null), null), 
	new HTML\UI\Menubar\Pad($PadKey = "Download", new HTML\UI\Menubar\Pad\Item(null, $APP->URL("Download", "Menubar-{$LeftPanelNavigationMenubarKey}-{$PadKey}"), "home.png", null), null), 
	new HTML\UI\Menubar\Pad("Documentation", new HTML\UI\Menubar\Pad\Item(null, null, "home.png", null), [
		new HTML\UI\Menubar\Pad($PadKey = "Installation", new HTML\UI\Menubar\Pad\Item(null, $APP->URL("Installation", "Menubar-{$LeftPanelNavigationMenubarKey}-Documentation-{$PadKey}"), "test.png", null), null), 
		new HTML\UI\Menubar\Pad($PadKey = "Configuration", new HTML\UI\Menubar\Pad\Item(null, $APP->URL("Configuration", "Menubar-{$LeftPanelNavigationMenubarKey}-Documentation-{$PadKey}"), "test.png", null), null), 
		new HTML\UI\Menubar\Pad($PadKey = "ObjectReference", new HTML\UI\Menubar\Pad\Item("Object reference", $APP->URL("ObjectReference", "Menubar-{$LeftPanelNavigationMenubarKey}-Documentation-{$PadKey}"), "object.png", null), null), 
		new HTML\UI\Menubar\Pad($PadKey = "FunctionReference", new HTML\UI\Menubar\Pad\Item("Function reference", $APP->URL("FunctionReference", "Menubar-{$LeftPanelNavigationMenubarKey}-Documentation-{$PadKey}"), "function.png", null), null), 
	]), 
	new HTML\UI\Menubar\Pad($PadKey = "About", new HTML\UI\Menubar\Pad\Item("About us", $APP->URL("About", "Menubar-{$LeftPanelNavigationMenubarKey}-{$PadKey}"), "home.png", null), null), 
	new HTML\UI\Menubar\Pad($PadKey = "Contact", new HTML\UI\Menubar\Pad\Item("Contact us", $APP->URL("Contact", "Menubar-{$LeftPanelNavigationMenubarKey}-{$PadKey}"), "home.png", null), null), 
	new HTML\UI\Menubar\Pad("Test", new HTML\UI\Menubar\Pad\Item(null, null, "test.png", null), [
		new HTML\UI\Menubar\Pad($PadKey = "HTML-UI-Menubar", new HTML\UI\Menubar\Pad\Item("HTML / UI / Menubar", $APP->URL("Test/Object/HTML/UI/Menubar", "Menubar-{$LeftPanelNavigationMenubarKey}-Test-{$PadKey}"), "test.png", null), null), 
	]), 
], "http://localhost/Projects/sPHPX/Template/image/icon/", HTML\UI\Menubar::STYLE_ACCORDION, "Menubar-Custom-Dark");

?><input type="checkbox" id="DocumentAlternateTheme" class="Hidden" onchange="sJS.HTTP.Cookie('AlternateTheme', this.checked, 7);">
<input type="checkbox" id="LeftPanelToggleSwitch" class="Hidden" onchange="sJS.HTTP.Cookie('LeftPanel', this.checked, 7);">

<div class="LeftPanel">
	<section class="SectionTop">
		<a href="#" class="Name" onclick="alert('TODO: Navigate to user profile page.');">John Doe &amp; Jane Doe</a>
		<img src="https://birikfestival.com/wp-content/uploads/2014/10/speaker-2-v2.jpg" alt="Avatar" class="Avatar">

		<div class="Action">
			<a href="#" class="Item">Sign in</a>
			<a href="#" class="Item">Sign up</a>
			<a href="#" class="Item">Help</a>
		</div>
	</section>

	<nav class="SectionMiddle">
		<?=$LeftPanelNavigation->HTML()?>
	</nav>
	
	<section class="SectionBottom">
		<a href="#" onclick="alert('TODO: Navigate to about us page.');">Application 1.2.3</a>
	</section>
</div>

<span class="LeftPanelToggleSwitch">✖</span>

<div class="TopPanel">
	<label for="LeftPanelToggleSwitch" class="LeftPanelToggleSwitch"></label>

	<div class="Content">				
		<a href="./" class="Left">
			<img src="./image/logo.png" alt="Logo" class="Icon">
			<span class="Caption">Application</span>
		</a>

		<nav class="Navigation">
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">Features</span></a>
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">Mechanism</span></a>
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">How to</span></a>
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">Reference</span></a>
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">Download</span></a>
			<a href="#" class="Item"><img src="https://ybx.bondstein.com/image/logo.png" alt="Message" class="Icon"><span class="Caption">Contact</span></a>
			<label for="DocumentAlternateTheme" title="Light/dark mode" class="Item"><span class="Caption"></span></label>
		</nav>
	</div>
</div>

<header>
	<div class="Content">
		<nav class="Navigation">
			<a href="#" class="Item">Latest news</a>
			<a href="#" class="Item">Latest tutorial</a>
			<a href="#" class="Item">Latest release 10.1.58251 on Jul 24, 2021</a>
		</nav>
	</div>
</header>

<main>