var sJS = {
	DHTML: {
		Autofill: {
			Make: function(
				InputObject, // ID or object reference of the input element to make autofill for
				MinimumLength, // Minimum length of characters to trigger the autofill
				OnSuggestion, // URL to fetch autofill suggestion data in JSON format. Alternatively, a callback function to trigger for static data
				ValueElementName, // Name of the hidden input element to hold the value data for the selected autifill option (automatically created if the name is provided with)
				ValueKey, // Data field key name to pick up the option value from the data record (automatically determined if not provided with)
				CaptionKey, // Data field key name to pick up the option caption from the data record (ValueKey is used if not provided with)
				OnFill, // Callback function to trigger upon selecting the autofill option
				DefaultCaption, // Default caption to fill in the InputObject with
				DefaultValue, // Default value to fill in the ValueElement with
                MultiSelect, // Allow multiple item selection like tag buttons
				Node, // JSON child node to find options within (in case if options are not return in base node)
				StatusCaption = 'Searching' // Caption for the status element while searching/processing
			){
				// Move the input element into a container
				var InputContainer = document.createElement('div');
				InputContainer.className = 'Autofill';

				if(typeof InputObject == 'string')InputObject = document.getElementById(InputObject);
				InputObject.autocomplete = 'off';
				if(DefaultCaption)InputObject.value = DefaultCaption;
				InputObject.parentNode.insertBefore(InputContainer, InputObject);
				InputContainer.appendChild(InputObject);

				// Set default parameter values if not provided with
				if(!ValueElementName)ValueElementName = null;
				if(!ValueKey)ValueKey = ValueElementName;
				if(!CaptionKey)CaptionKey = InputObject.name;

                if(MultiSelect){
                    objMultiSelectOptionContainer = document.createElement('div');
                    objMultiSelectOptionContainer.className = 'OptionContainer';
                    objMultiSelectOptionContainer.innerHTML = '<span id=\'sJS_Autofill_MultiSelect_ItemCounter_' + ValueElementName + '\' class=\'Counter\'>0</span>';

                    InputContainer.appendChild(objMultiSelectOptionContainer);
                }

                if(ValueElementName){ // Create an element to hold the option value
                    var ValueObject = document.createElement('input');
                    ValueObject.type = 'hidden';
                    ValueObject.name = ValueElementName;
                    ValueObject.id = ValueElementName;
                    if(DefaultValue)ValueObject.value = DefaultValue;

                    if(!MultiSelect)InputContainer.appendChild(ValueObject);
                }

				// Create selector container element after the input element
				var SelectorObject = document.createElement('span');
				SelectorObject.className = 'Option';
				InputObject.parentNode.insertBefore(SelectorObject, InputObject.nextSibling);

				// Create status element
				var StatusElement = document.createElement('div');
				StatusElement.className = 'Status';
				StatusElement.style.display = 'none';
				StatusElement.innerHTML = StatusCaption;
				InputContainer.appendChild(StatusElement);

				InputObjectOldKeyUpEvent = InputObject.onkeyup ? InputObject.onkeyup : null;

				InputObject.onkeyup = function(event){ // Action upon key press (on key up) in the input
					// Reset value upon edit
                    if(
                            (
                                    (event.keyCode >= 32 && event.keyCode <= 126 ) // Value changed/edited
                                ||  InputObject.value == '' // Erased
                            )
                        &&  ValueElementName // Value element exists
                    ){
						//console.log('User is typing in the InputObject');
                        ValueObject.value = '';
                    }

					// Set focus to the option selector upon down arrow in the input element
					if(SelectorObject.style.display == 'block'){
						if(event.keyCode == 40){ // Down arrow
							SelectorObject.firstChild.focus(); // Focus the first option in the selector

							return true; // No need to do anything else
						}
						else if(event.keyCode == 27){ // Escape
							sJS.DHTML.Autofill.Hide(SelectorObject, InputObject, true); // Hide selector

							return true; // No need to do anything else
						}
						else{

						}
					}

					// Some value has been typed in the input object
                    if(InputObject.value.length >= MinimumLength && event.keyCode != 13 && event.keyCode != 27){
						if(typeof OnSuggestion == 'string'){ // URL to fetch options JSON from
							AJAXCall = new XMLHttpRequest();

							AJAXCall.onreadystatechange = function(){
								if(
                                        this.readyState == 4
                                    &&  this.status == 200
								){
									Item = JSON.parse(AJAXCall.responseText.trim());
									if(Node)Item = Item[Node];
									//console.log(Item);
									if(Item.length)sJS.DHTML.Autofill.Populate(
										Item,
										SelectorObject,
										InputObject,
										ValueElementName ? ValueObject : null,
										ValueKey,
										CaptionKey,
										OnFill,
										MultiSelect ? objMultiSelectOptionContainer : null
									);

									StatusElement.style.display = 'none'; // Hide status element
								}

								return true;
							}; //console.log(OnSuggestion + '&__Keyword=' + InputObject.value);

							StatusElement.style.display = ''; // Show status element
							AJAXCall.open('GET', OnSuggestion + '&__Keyword=' + InputObject.value, true);
							AJAXCall.send();
						}
						else if(Array.isArray(OnSuggestion)){ // Array of suggestion options
							SuggestionOption = OnSuggestion;
							SuggestionItem = []; // Assume no suggestion item is available

							if(SuggestionOption.length){ // Only if items are defined for suggestion
								SuggestionCounter = -1; // Keep track of suggestion proposal item count

								for(SuggestionOptionCounter = 0; SuggestionOptionCounter < SuggestionOption.length; SuggestionOptionCounter++){ // Iterate through each suggestion item
									// Determine current suggestion item value to check against current input value
									if(typeof SuggestionOption[SuggestionOptionCounter] == 'object'){ // Suggestion is an object
										CurrentSuggestionOption = SuggestionOption[SuggestionOptionCounter][CaptionKey];
									}
									else{ // Suggestion item is just a value
										CurrentSuggestionOption = SuggestionOption[SuggestionOptionCounter];
									}

									if( // If current suggestion item has the typed in value within (make it case insensitive)
											CurrentSuggestionOption.toUpperCase().indexOf(InputObject.value.toUpperCase()) != -1
										||	!InputObject.value.length // Empty search value, nothing to match with
									){
										SuggestionCounter++; // Increse the suggestion proposal counter

										// Add matched suggestion item to proposal
										if(typeof SuggestionOption[SuggestionOptionCounter] == 'object'){ // Suggestion item is already an object
											SuggestionItem[SuggestionCounter] = SuggestionOption[SuggestionOptionCounter];
										}
										else{ // Make the proposal item an array from the suggestion item
											SuggestionItem[SuggestionCounter] = {[ValueKey]: SuggestionOption[SuggestionOptionCounter], [CaptionKey]: SuggestionOption[SuggestionOptionCounter], };
										}
									}
								}
							}

							// Populate the autofill option list with found suggestion items
							sJS.DHTML.Autofill.Populate(SuggestionItem, SelectorObject, InputObject, ValueElementName ? ValueObject : null, ValueKey, CaptionKey, OnFill, MultiSelect ? objMultiSelectOptionContainer : null);
						}
						else{ // Callback function to define options
							if((Item = OnSuggestion(InputObject.value)).length)sJS.DHTML.Autofill.Populate(
                                Item,
                                SelectorObject,
                                InputObject,
                                ValueElementName ? ValueObject : null,
                                ValueKey,
                                CaptionKey,
                                OnFill,
                                MultiSelect ? objMultiSelectOptionContainer : null
                            );
						}

						return true;
					}

					if(InputObjectOldKeyUpEvent)InputObjectOldKeyUpEvent(event);

					return true;
				};

				if(!MinimumLength)InputObject.onclick = InputObject.onkeyup; // Use focus event same as key up event

				// Hide selector when focus moves off the autofill
                InputObject.onblur = function(){ // We need to WRITE this function as this is asynchronous
                    window.setTimeout(function(){
						//console.log(document.activeElement.id);
                        if(
                                document.activeElement.id != InputObject.id
                            &&  document.activeElement.id.substring(0, document.activeElement.id.indexOf('[')) != 'sJS_DHTML_Autofill_Option_Item_' + ValueObject.id
                        ){
                            sJS.DHTML.Autofill.Hide(SelectorObject, InputObject, false); // Hide selector
                        }
                    }, 500);
				}

				return true;
			},
			Populate: function(Item, SelectorObject, InputObject, ValueObject, ValueKey, CaptionKey, OnFill, MultiSelectOptionContainer){
				SelectorObject.innerHTML = ''; // Clear existing options from the selector

				// Set default ValueKey & CaptionKey if Item is an object or array (not a scaler value)
				if(typeof Item[0] == 'object' || typeof Item[0] == 'array'){
					if(!ValueKey)ValueKey = Object.keys(Item[0])[0];
					if(!CaptionKey)CaptionKey = ValueKey;
				}

				for(ItemCounter = 0; ItemCounter < Item.length; ItemCounter++){ // Create options
					SelectorObject.onkeyup = function(event){
						if(event.keyCode == 27){ // Escape
							sJS.DHTML.Autofill.Hide(SelectorObject, InputObject, true); // Hide selector
						}

						return true;
					}

					// Create a button for the option
					ItemOption = document.createElement('button');
					ItemOption.type = 'button';
					ItemOption.className = 'Item';
                    ItemOption.id = 'sJS_DHTML_Autofill_Option_Item_' + ValueObject.id + '[' + ItemCounter + ']';

					if(typeof Item[ItemCounter] == 'object' || typeof Item[ItemCounter] == 'array'){ // Value and caption are separate
						ItemOption.value =  Item[ItemCounter][ValueKey]; // Value of the option
						ItemOption.dataCaption = Item[ItemCounter][CaptionKey]; // Caption of the option
					}
					else{ // Value and caption are same
						ItemOption.value = ItemOption.dataCaption = Item[ItemCounter];
					}

					if(ItemOption.dataCaption)ItemOption.innerHTML = ItemOption.dataCaption.replace(InputObject.value, '<span class=\'Highlight\'>' + InputObject.value + '</span>');

					ItemOption.onkeyup = function(event){ // Action upon key press with the option
						if(event.keyCode == 38){ // Up arrow
							if(this.previousSibling){
								this.previousSibling.focus(); // Focus previous option
							}
							else{
								//console.log('Focus the input element beyond the first opion');
								InputObject.focus(); // Focus the input element beyond the first opion
							}
						}
						else if(event.keyCode == 40){ // Down arrow
							if(this.nextSibling)this.nextSibling.focus(); // Focus next option
						}
						else{

						}

						return true;
					}

					ItemOption.onclick = function(event){ // Action upon click/selection with the option
						if(ValueObject)ValueObject.value = this.value; // Set value to designated element

						InputObject.value = this.dataCaption; // Caption as value of input element
						InputObject.dataValue = this.value; // Set data value attribute to input element
						if(InputObject.onchange)InputObject.onchange(); // Fire OnChange event of input element, if it has one
						//console.log('sJS.DHTML.Autofill.Populate: InputObject.value = ' + this.dataCaption);

						sJS.DHTML.Autofill.Hide(SelectorObject, InputObject, true); // Hide selector
						if(OnFill)OnFill(InputObject.dataValue, InputObject.value); // OnFill callback

                        if(MultiSelectOptionContainer){
                            MultiSelectOptionIDPrefix = 'sJS_Autofill_MultiSelect_Option_';
                            MultiSelectOptionExists = false;

                            if(!document.getElementById('' + MultiSelectOptionIDPrefix + ValueObject.name + '[' + ValueObject.value + ']')){
                                objMultiSelectOption = document.createElement('span');
                                objMultiSelectOption.className = 'Option';
                                objMultiSelectOption.innerHTML = '<input type=\'hidden\' id=\'' + MultiSelectOptionIDPrefix + ValueObject.name + '[' + ValueObject.value + ']\' name=\'' + ValueObject.name + '[]\' value=\'' + ValueObject.value + '\'><span class=\'Caption\'>' + InputObject.value + '</span><button type=\'button\' class=\'Remove\' onclick=\'this.parentNode.parentNode.removeChild(this.parentNode);\'>❌</button>';
                                MultiSelectOptionContainer.appendChild(objMultiSelectOption);

                                document.getElementById('sJS_Autofill_MultiSelect_ItemCounter_' + ValueObject.name + '').innerHTML = '' + (MultiSelectOptionContainer.childElementCount - 1) + '';
                            }
                        }

						return true;
					};

                    // Hide selector when focus moves off the autofill
                    ItemOption.onblur = function(){ // We need to WRITE this function as this is asynchronous
                        window.setTimeout(function(){
							//console.log(document.activeElement.id);
                            if(
                                    document.activeElement.id != InputObject.id
                                &&  document.activeElement.id.substring(0, document.activeElement.id.indexOf('[')) != 'sJS_DHTML_Autofill_Option_Item_' + ValueObject.id
                            ){
                                sJS.DHTML.Autofill.Hide(SelectorObject, InputObject, false); // Hide selector
                            }
                        }, 500);
                    }

					SelectorObject.appendChild(ItemOption); // Add this option to the selector
				}

				SelectorObject.style.display = 'block'; // Show option selector

				return true;
			},
			Hide: function(SelectorObject, InputObject, SetFocusToInputObject){
				SelectorObject.style.display = 'none'; // Hide option selector
				//console.log('Keep the cursor/focus within the input');
				if(SetFocusToInputObject){ // Keep the cursor/focus within the input
                    InputObject.focus();
                    sJS.DHTML.SelectAll(InputObject);
                }

				return true;
			},
		},
		Select: {
			Child: {
				Populate: function(APIURL, ChildObject, ParentObject, CaptionKey = null, DefaultChildValue = null, ValueKey = null){
					// Set default argument value
					if(!ValueKey)ValueKey = ChildObject;
					if(!CaptionKey)CaptionKey = ValueKey;
			
					if(typeof ChildObject == 'string')ChildObject = document.getElementById(ChildObject); // Get child object
					if(typeof ParentObject == 'string')ParentObject = document.getElementById(ParentObject); // Get parent object
			
					// Clear selection and hide it
					ChildObject.value = null;
					//ChildObject.selectedIndex = 0;
					ChildObject.innerHTML = '';
					ChildObject.style.display = 'none';
			
					if(ParentObject.value)sJS.HTTP.Get( // Call API for options
						APIURL + ParentObject.value, // URL
						function(Response){ // OnSuccess
							Response = JSON.parse(Response); //console.log(Response); // Parse API JSON reponse
							ChildObject.appendChild(document.createElement('OPTION')); // Create a blank option first
							
							Response.forEach(function(Item, ItemIndex){ // Create available options
								var Option = document.createElement('OPTION');
								Option.value = Item[ValueKey];
								Option.innerHTML = Item[CaptionKey];
								ChildObject.appendChild(Option);
								
								if(Item[ValueKey] == DefaultChildValue)ChildObject.value = Item[ValueKey]; // Set default option
							});
		
							if(Response.length)ChildObject.style.display = ''; // Make selection visible when options are available
						}, 
						function(StatusCode, ErrorMessage){ // OnFail
							alert('Code: ' + StatusCode + '\nMessage' + ErrorMessage);
						}
					);
				}, 
			
				Attach: function(ParentObject, APIURL, ChildObject, CaptionKey = null, DefaultChildValue = null, ValueKey = null){
					// Hook ParentObject OnChange event
					if(typeof ParentObject == 'string')ParentObject = document.getElementById(ParentObject); // Get parent object
					ParentObject.onchange = function(){sJS.DHTML.Select.Child.Populate(APIURL, ChildObject, ParentObject, CaptionKey, DefaultChildValue, ValueKey);}
			
					// Set initial option selection
					this.Populate(APIURL, ChildObject, ParentObject, CaptionKey, DefaultChildValue, ValueKey);
				}, 
			}, 
			
			// DEPRECATED
			Depend: function(TargetElement, SourceElement, OnLoad, Value){
				var OldOnChange = SourceElement.onchange ? SourceElement.onchange : null;

				SourceElement.onchange = function(){
					if(typeof OnLoad == 'string'){
						AJAXCall = new XMLHttpRequest();

						AJAXCall.onreadystatechange = function(){
							if(this.readyState == 4 && this.status == 200 && (Item = JSON.parse(AJAXCall.responseText)).length)sJS.DHTML.Select.Populate(Item, TargetElement, Value);
							return true;
						};

						AJAXCall.open('GET', OnLoad + '&__Keyword=' + SourceElement.value, true);
						AJAXCall.send();
					}
					else{
						if((Item = OnLoad(this.value)).length)sJS.DHTML.Select.Populate(Item, TargetElement, Value);
					}

					if(OldOnChange)OldOnChange();

					return true;
				};

				SourceElement.onchange();

				return true;
			},

			// DEPRECATED
			Populate: function(Item, TargetElement, Value){
				TargetElement.innerHTML = '';

				for(ItemCounter = 0; ItemCounter < Item.length; ItemCounter++){
					Option = document.createElement('option');

					if(Array.isArray(Item[ItemCounter])){
						Option.value = Item[ItemCounter][0];
						Option.innerHTML = Item[ItemCounter][1];
					}
					else{
						Option.value = Option.innerHTML = Item[ItemCounter];
					}

					if(Option.value == Value)Option.selected = true;

					TargetElement.appendChild(Option);
				}

				return true;
			},
		},
		Toast: function(Content, CSSSelector, LifeTime, ToastContainer){
			if(ToastContainer){
				if(typeof ToastContainer == 'string')ToastContainer = document.getElementById(ToastContainer);
			}
			else{
				if(!(ToastContainer = document.getElementById('ToastContainer'))){
					ToastContainer = document.createElement('div');
					ToastContainer.id = 'ToastContainer';
					ToastContainer.className = 'ToastContainer';
					document.body.appendChild(ToastContainer);
				}
			}

			var CurrentTime = new Date();

			Toast = document.createElement('div');
			Toast.id = 'Toast_' + sJS.UUID();
			Toast.className = 'Toast';
			if(CSSSelector)Toast.classList.add(CSSSelector);
			Toast.innerHTML = Content;
			ToastContainer.appendChild(Toast);
			setTimeout(function(){ToastContainer.removeChild(ToastContainer.childNodes[0]);}, LifeTime ? LifeTime : 4000);

			return true;
		},
		SelectAll: function(InputObject){
			if(typeof InputObject == 'string')InputObject = document.getElementById(InputObject);
			InputObject.setSelectionRange(0, InputObject.value.length);

			return true;
		},
		Overlapper: {
			Show: function(Content, AllowClose = true, AllowCloseAnywhere = true){
				if(AllowClose === undefined)AllowClose = true;
				if(AllowCloseAnywhere === undefined)AllowCloseAnywhere = AllowClose;

				var objOverlapper = document.getElementById('_Overlapper');

				if(!objOverlapper){
					objOverlapper = document.createElement('div');
					objOverlapper.id = '_Overlapper';
					objOverlapper.innerHTML = '<div id="_OverlapperContent" class="Content"></div>' + (AllowClose ? '<button type="button" class="Button Button_Close" onclick="sJS.DHTML.Overlapper.Hide();"><img src="./image/icon/close.png" alt="Close" class="Icon"><span class="Caption">X</span><button>' : '') + '';
					objOverlapper.className = '_Overlapper';
					if(AllowCloseAnywhere)objOverlapper.onclick = function(){sJS.DHTML.Overlapper.Hide()};

					document.body.appendChild(objOverlapper);
				}

				document.getElementById('_OverlapperContent').innerHTML = Content;
				objOverlapper.style.display = 'block';

				return true;
			},
			Hide: function(InParent){
				if(InParent === undefined)InParent = false;

				var Source = InParent ? window.parent.document : document;
				Source.getElementById('_Overlapper').style.display = 'none';
				Source.getElementById('_OverlapperContent').innerHTML = '';

				return true;
			}, 
			ShowInIFrame(URL, AllowClose = true, AllowCloseAnywhere = true, CSSClass = ''){
				sJS.DHTML.Overlapper.Show('<iframe src="' + URL + '" class="' + CSSClass + '"></iframe>', AllowClose, AllowCloseAnywhere);

				return true;
			}
		},
		InsertAtCursor: function(areaId,text){
			// Credit goes to https://gist.github.com/fnicollier/4258461
			var txtarea = document.getElementById(areaId);
			var scrollPos = txtarea.scrollTop;
			var strPos = 0;
			var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ?
				"ff" : (document.selection ? "ie" : false ) );
			if (br == "ie") {
				txtarea.focus();
				var range = document.selection.createRange();
				range.moveStart ('character', -txtarea.value.length);
				strPos = range.text.length;
			}
			else if (br == "ff") strPos = txtarea.selectionStart;

			var front = (txtarea.value).substring(0,strPos);
			var back = (txtarea.value).substring(strPos,txtarea.value.length);
			txtarea.value=front+text+back;
			strPos = strPos + text.length;
			if (br == "ie") {
				txtarea.focus();
				var range = document.selection.createRange();
				range.moveStart ('character', -txtarea.value.length);
				range.moveStart ('character', strPos);
				range.moveEnd ('character', 0);
				range.select();
			}
			else if (br == "ff") {
				txtarea.selectionStart = strPos;
				txtarea.selectionEnd = strPos;
				txtarea.focus();
			}
			txtarea.scrollTop = scrollPos;
		}, 
		Notification: function(Message, Timeout = 5000, Title = null, ItemCSSClass = null, IDPrefix = null, ItemUUID = null){
			if(!Timeout)Timeout = 5000;
			if(!IDPrefix)IDPrefix = '';

			var objNotification = document.getElementById(IDPrefix + '__sJS_Notification');
			
			if(objNotification){
				var objNotificationItemContainer = document.getElementById(IDPrefix + '__sJS_NotificationItemContainer');
				var objNotificationItemCounter = document.getElementById(IDPrefix + '__sJS_NotificationItemCounter');
			}
			else{
				var objNotification = document.createElement('DIV');
				objNotification.id = IDPrefix + '__sJS_Notification';

				var objSwitch = document.createElement('INPUT');
				objSwitch.id = IDPrefix + '__sJS_NotificationSwitch';
				objSwitch.type = 'checkbox';
				objSwitch.checked = true;
	
				var objNotificationItemContainer = document.createElement('DIV');
				objNotificationItemContainer.id = IDPrefix + '__sJS_NotificationItemContainer';

				var objNotificationItemCounter = document.createElement('LABEL');
				objNotificationItemCounter.htmlFor = objSwitch.id;
				objNotificationItemCounter.id = IDPrefix + '__sJS_NotificationItemCounter';
				objNotificationItemCounter.innerHTML = '0';

				objNotification.appendChild(objSwitch);
				objNotification.appendChild(objNotificationItemContainer);
				objNotification.appendChild(objNotificationItemCounter);
				document.body.appendChild(objNotification);
			}

			var objItem = document.createElement('DIV');
			if(ItemUUID)objItem.id = IDPrefix + '__sJS_Notification_Item_' + ItemUUID;
			objItem.className = 'Item' + (ItemCSSClass ? ' ' + ItemCSSClass : '');
			objItem.innerHTML = '' + (Title ? '<div class="Title">' + Title + '</div>' : '') + '<div class="Message">' + Message + '</div>';

			objNotificationItemContainer.appendChild(objItem);
			objNotificationItemContainer.scrollTo(0, objNotificationItemContainer.scrollHeight);
			objNotificationItemCounter.innerHTML = objNotificationItemContainer.childNodes.length;

			setTimeout(function(){
				objNotificationItemContainer.removeChild(objNotificationItemContainer.childNodes[0]);
				objNotificationItemCounter.innerHTML = objNotificationItemContainer.childNodes.length;
			}, Timeout);
		}, 
		Slider: {
			SetSlide: function(Slider, ItemCounter){ //console.log('function SliderSetItem(' + ItemCounter + ')');
				Slider.Item.forEach(function(Item, Index){Item.Element.className = 'Item';});
				Slider.Indicator.Item.forEach(function(Item, Index){Item.className = 'Item';});

				if(ItemCounter == '-')ItemCounter = Slider.CurrentItem - Slider.FlowStep;
				if(ItemCounter == '+')ItemCounter = Slider.CurrentItem + Slider.FlowStep;

				Slider.CurrentItem = ItemCounter;
				if(Slider.CurrentItem < 1)Slider.CurrentItem = Slider.CurrentItem == 1 - Slider.FlowStep ? Slider.Item.length : Slider.CurrentItem + Slider.FlowStep - 1;
				if(Slider.CurrentItem > Slider.Item.length)Slider.CurrentItem = 1;

				FirstItemCounter = Slider.CurrentItem;
				if(FirstItemCounter + Slider.Step - 1 > Slider.Item.length)FirstItemCounter = Slider.Item.length - Slider.Step + 1;

				//Slider.Element.style.backgroundImage = Slider.Item[Slider.CurrentItem - 1].Element.style.backgroundImage;
				Slider.Item[Slider.CurrentItem - 1].Element.className = 'Item Active';
				Slider.Indicator.Item[Slider.CurrentItem - 1].className = 'Item Active';

				if(!Slider.OnSlideSet(Slider, FirstItemCounter)){
					var MovementAmount = ((-1) * (FirstItemCounter - 1) * (Slider.Vertical ? Slider.Element.offsetHeight : Slider.Element.offsetWidth) / Slider.Step) + 'px';

					if(Slider.Vertical){
						Slider.Container.style.top = MovementAmount;
					}
					else{
						Slider.Container.style.left = MovementAmount;
					}
				}

				Slider.Indicator.Progress.style.transition = 'all ' + Slider.Interval + 's ease-in';
				Slider.Indicator.Progress.style.width = '100%';

				return Slider;
			}, 
			Start: function(Slider){ //console.log('function SliderStart(Slider)');
				Slider.Timer = setInterval(function(){
					Slider.Indicator.Progress.style.transition = 'none';
					Slider.Indicator.Progress.style.width = '0';

					Slider = sJS.DHTML.Slider.SetSlide(Slider, Slider.ReverseDirection ? '-' : '+');

					return true;
				}, Slider.Interval * 1000);

				return Slider;
			}, 
			Stop: function(Slider){ //console.log('function SliderStop(Slider)');
				clearInterval(Slider.Timer);
				Slider.Timer = null;

				return Slider;
			}, 
			Make: function(
				ElementID, // ID of the HTML element to embade the Slider into
				Item = [], // Array of Slide objecct: [{Picture: '', Title: '', Description: '', URL: '', LinkCaption: '', Target: '', OnClick: '', }]
				PicturePath = './image/slider/', // Global path prefix for slide pictures
				Vertical = false, // Move vertically than horizontally
				StyleClass = 'sJSSlider', // Default CSS class name; do not forget to include sjs/slider.css
				Interval = 5, // Seconds for slide change
				Step = 1, // Number of slides to show at once
				FlowStep = 1, // Number of slides to change at once
				ReverseDirection = false, // Advance slides to opposite directtion; default is to left
				OnSlideSet = function(Slider, FirstItemCounter){return false;}, // Function to trigger on slide change for custom slide manipulation; return false for default transition
				CurrentItem = 1 // Default slide at start
			){ // Returns Slider object
				var Slider = { // Create Slider object to return
					ElementID: ElementID, 
					Item: Item ? Item : [], 
					PicturePath: PicturePath = PicturePath, 
					Vertical: Vertical ? Vertical : false, 
					StyleClass: StyleClass ? StyleClass : 'sJSSlider', 
					Interval: Interval ? Interval : 5, 
					Step: Step ? Step : 1, 
					FlowStep: FlowStep ? FlowStep : 1, 
					ReverseDirection: ReverseDirection ? ReverseDirection : false, 
					OnSlideSet: OnSlideSet ? OnSlideSet : function(Slider, FirstItemCounter){return false;}, 
					CurrentItem: CurrentItem ? CurrentItem : 1, 
				};
	
				if(Slider.ElementID){
					if(Slider.Item.length){
						Slider.Element = document.getElementById(Slider.ElementID);
						Slider.Element.className = Slider.StyleClass;
						Slider.Element.onmouseover = function(){sJS.DHTML.Slider.Stop(Slider)};
						Slider.Element.onmouseout = function(){sJS.DHTML.Slider.Start(Slider)};
	
						Slider.Container = document.createElement('DIV');
						Slider.Container.className = 'Container';
						Slider.Element.appendChild(Slider.Container);
	
						Slider.Indicator = {};
						Slider.Indicator.Item = [];
	
						Slider.Indicator.Element = document.createElement('DIV');
						Slider.Indicator.Element.className = 'Indicator';
						Slider.Element.appendChild(Slider.Indicator.Element);
	
						Slider.Indicator.Progress = document.createElement('DIV');
						Slider.Indicator.Progress.className = 'Progress';
						Slider.Indicator.Progress.style.width = '0';
						Slider.Indicator.Element.appendChild(Slider.Indicator.Progress);
	
						Slider.Navigation = {};
						Slider.Navigation.Previous = document.createElement('BUTTON');
						Slider.Navigation.Previous.className = 'Navigation NavigationPrevious';
						Slider.Navigation.Previous.innerHTML = '◁';
						Slider.Navigation.Previous.onclick = function(){sJS.DHTML.Slider.SetSlide(Slider, '-')};
						Slider.Element.appendChild(Slider.Navigation.Previous);
	
						Slider.Navigation.Next = document.createElement('BUTTON');
						Slider.Navigation.Next.className = 'Navigation NavigationNext';
						Slider.Navigation.Next.innerHTML = '▷';
						Slider.Navigation.Next.onclick = function(){sJS.DHTML.Slider.SetSlide(Slider, '+')};
						Slider.Element.appendChild(Slider.Navigation.Next);
	
						Slider.Item.forEach(function(Item, Index){
							var Slide = document.createElement('DIV');
							Slide.className = 'Item';
							Slide.style.width = (100 / Slider.Step) + '%';
							Slide.style.backgroundImage = 'url(\'' + Slider.PicturePath + Item.Picture + '\')', 
							Slide.innerHTML = '<div class="Content"><div class="Title">' + Item.Title + '</div><div class="Description">' + Item.Description + '</div>' + (Item.URL || Item.OnClick ? '<a href="' + Item.URL + '" target="' + Item.Target + '" class="Link" onclick="' + Item.OnClick + '">' + Item.LinkCaption + '</a>' : '') + '</div>';
							Slider.Container.appendChild(Slide);
							Slider.Item[Index].Element = Slide;
	
							var IndicatorItem = document.createElement('BUTTON');
							IndicatorItem.className = 'Item';
							IndicatorItem.onclick = function(){sJS.DHTML.Slider.SetSlide(Slider, Index + 1)};
							IndicatorItem.innerHTML = Index + 1;
							Slider.Indicator.Element.appendChild(IndicatorItem);
							Slider.Indicator.Item[Index] = IndicatorItem;
						});
	
						Slider.Item[Slider.CurrentItem - 1].Element.className = 'Item Active';
						Slider.Indicator.Item[Slider.CurrentItem - 1].className = 'Item Active';
						//Slider.Element.style.backgroundImage = Slider.Item[0].Element.style.backgroundImage;
	
						Slider.Timer = this.Start(Slider).Timer;
	
						Slider.Indicator.Progress.style.transition = 'all ' + Slider.Interval + 's ease-in';
						Slider.Indicator.Progress.style.width = '100%';
					}
					else{
						alert('Slider.Item missing!');
					}
				}
				else{
					alert('Slider.ElementID missing!');
				}
	
				return Slider;
			}, 
		}, 
	},

	HTTP: {
		Get: function(URL, OnSuccess = function(Response, Header){}, OnFail = function(StatusCode, ErrorMessage){}, Asynchronus = true, TimeOutMS = null){
			return __HTTP_Transfer(
				URL, // String
				OnSuccess, // Function(Response)
				'GET', // Method: GET | POST
				[], // POST data
				[], // FILE
				OnFail, // Function(Code, Description)
				Asynchronus, // BOOLEAN
				TimeOutMS // Milisecond in positive integer
			);
		},
		Post: function(URL, OnSuccess = function(Response, Header){}, Data = [], File = [], OnFail = function(StatusCode, ErrorMessage){}, Asynchronus = true, TimeOutMS = 5000){
			return __HTTP_Transfer(URL, OnSuccess, 'POST', Data, File, OnFail, Asynchronus, TimeOutMS);
		},

		Cookie: function(Name, Value = null, ExpiryDays = null){
			if(Value === null){ // GET
				var c_value = document.cookie;
				var c_start = c_value.indexOf(" " + Name + "=");
			
				if (c_start == -1)c_start = c_value.indexOf(Name + "=");
			
				if (c_start == -1){
					c_value = null;
				}
				else{
					c_start = c_value.indexOf("=", c_start) + 1;
					var c_end = c_value.indexOf(";", c_start);
			
					if (c_end == -1)c_end = c_value.length;
					c_value = unescape(c_value.substring(c_start,c_end));
				}
			
				//console.log('Cookie get: ' + Name + ' = ' + c_value);
				Result = c_value;
			}
			else{ // SET
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + ExpiryDays);
	
				var c_value = escape(Value) + ((ExpiryDays == null) ? '' : '; expires=' + exdate.toUTCString()) + '; SameSite=Lax';
				document.cookie = Name + "=" + c_value;

				//console.log('Cookie set: ' + Name + ' = ' + Value);
				Result = c_value;
			}

			return Result;
		}, 

		GetAtInterval: function(
			Interval, // Milisecond in positive integer; Minimum = 2
			URL, // String
			OnSuccess = function(Response, Header){}, // Function(Response, Header)
			OnFail = function(Code, Description){}, // Function(Code, Description)
			TimeOut = 5000, // Milisecond in positive integer
			ProcessJSON = false, // Boolean, 
			OnStart = function(){}, // Callback function on HTTP invoke process start			
			Data = [], // POST field // Needs work
			File = [] // FILE field // Needs work
		){
			// Validate argument
			if(Interval < 2)Interval = 2;

			// Make sure the TimeOut is less than Interval
			var MaximumTimeOut = Interval - 1;
			if(TimeOut > MaximumTimeOut)TimeOut = MaximumTimeOut;

			var Result = false;
			var FetchInProgress = false;
	
			Result = setInterval(function(){ //console.log('Request made');
				if(!FetchInProgress){
					FetchInProgress = true;
					OnStart(); // Callback function on HTTP invoke process start
	
					sJS.HTTP.Get(URL, function(Response, Header){ //console.log('Request succeeded'); // On success
						if(ProcessJSON){
							try{
								OnSuccess(JSON.parse(Response), Header);
							}
							catch(e){ //console.log(e);
								OnFail('-1', 'JSON parse failed\n\n' + Response);
							}
						}
						else{
							OnSuccess(Response, Header);
						}
	
						FetchInProgress = false;
					}, function(Code, Description){ //console.log('Request failed'); // On fail
						OnFail(Code, Description);
						FetchInProgress = false;
					}, true, TimeOut);
				}
			}, Interval);
	
			return Result;
		}, 
	},

	Geometry: {
		RadianToDegree: function(Angle){
			return Angle * 180 / Math.PI;
		},

		PointAngle: function(X2, Y2, X1, Y1, Segment){
			Angle = (sJS.Geometry.RadianToDegree(Math.atan2(Y2 - Y1, X2 - X1)) + 360) % 360;
			SegmentRange = 360 / Segment;

			Result = Segment ? Math.round(Angle / SegmentRange) : Angle;
			//console.log('Angle = ' + Angle + '; Segment = ' + Segment + '; SegmentRange: ' + SegmentRange + ';');
			return Result;
		}
	},

	Browser: {
		Notification: {
			Enabled: function(){
				return Notification.requestPermission();
			}, 
			Permission: function(){
				return this.Enabled() && this.Permission() != 'denied' ? true : false;
			}, 
			Create: function(Content, Title = null, Icon = null){ //console.log('sJS.Browser.Notification.Create()');
				var Result = false;

				if(Notification.requestPermission() && Notification.permission != 'denied'){
					var NotificationObject = {
						body: Content, 
					};

					if(Icon)NotificationObject.icon = Icon;

					new Notification(Title, NotificationObject);

					Result = true;
				}
				else{
					console.log('Either browser notification feature is not available or permission denied!');
				}
				
				return Result;
			}, 
		}, 
	}, 

	Time: {
		MonthName: function(MonthNumber, Short = false){
			var MonthName = new Array();
			MonthName[0] = "January";
			MonthName[1] = "February";
			MonthName[2] = "March";
			MonthName[3] = "April";
			MonthName[4] = "May";
			MonthName[5] = "June";
			MonthName[6] = "July";
			MonthName[7] = "August";
			MonthName[8] = "September";
			MonthName[9] = "October";
			MonthName[10] = "November";
			MonthName[11] = "December";

			var Result = MonthName[MonthNumber - 1];
			if(Short)Result = Result.substring(0, 3);

			return Result;
		}, 

		Format: function(TimeValue, FormatString = 'Y-m-d H:i:s'){ //console.log(TimeValue, FormatString);
			// TimeValue = JavaScript Date object, eg: new Date()
			// FormatString = Follow PHP date format symbols

			if(typeof TimeValue == 'string'){
				//console.log('Converting YYYY-MM-DD HH:II:SS string to Date object');
				var TimeValueSplitted = TimeValue.split(/[- :]/);
				TimeValue = new Date(Date.UTC(TimeValueSplitted[0], TimeValueSplitted[1] - 1, TimeValueSplitted[2], TimeValueSplitted[3], TimeValueSplitted[4], TimeValueSplitted[5]));
			} //console.log('TimeValue = ' + TimeValue, typeof TimeValue);

			PartYear = TimeValue.getFullYear();
			PartYearDoubleDigit = PartYear.toString().substring(2, 2);

			PartMonth = TimeValue.getMonth() + 1;
			PartMonthDoubleDigit = PartMonth.toString().padStart(2, '0');
			PartMonthName = this.MonthName(PartMonth);
			PartMonthShortName = PartMonthName.substring(0, 3);

			PartDay = TimeValue.getDate();
			PartDayDoubleDigit = PartDay.toString().padStart(2, '0');

			PartHour = TimeValue.getHours();
			PartHourDoubleDigit = PartHour.toString().padStart(2, '0');

			PartHour12Hour = (PartHour % 12) || 12;
			PartHour12HourDoubleDigit = PartHour12Hour.toString().padStart(2, '0');

			PartMinute = TimeValue.getMinutes();
			PartMinuteDoubleDigit = PartMinute.toString().padStart(2, '0');

			PartSecond = TimeValue.getSeconds();
			PartSecondDoubleDigit = PartSecond.toString().padStart(2, '0');

			PartMedian = (PartHour > 11 ? 'p' : 'a') + 'm';
			PartMedianUppercase = PartMedian.toUpperCase();

			// Convert place markers to something that won't interfere with result after replace
			FormatString = FormatString.replace('Y', '{Y}');
			FormatString = FormatString.replace('n', '{n}');
			FormatString = FormatString.replace('m', '{m}');
			FormatString = FormatString.replace('M', '{M}');
			FormatString = FormatString.replace('F', '{F}');
			FormatString = FormatString.replace('j', '{j}');
			FormatString = FormatString.replace('d', '{d}');
			FormatString = FormatString.replace('G', '{G}');
			FormatString = FormatString.replace('H', '{H}');
			FormatString = FormatString.replace('g', '{g}');
			FormatString = FormatString.replace('h', '{h}');
			FormatString = FormatString.replace('i', '{i}');
			FormatString = FormatString.replace('s', '{s}');
			FormatString = FormatString.replace('a', '{a}');
			FormatString = FormatString.replace('A', '{A}');

			// Replace with value per place marker
			var Result = FormatString.replace('{Y}', PartYear);
			//Result = Result.replace('{Y}', PartYear);

			Result = Result.replace('{n}', PartMonth);
			Result = Result.replace('{m}', PartMonthDoubleDigit);
			Result = Result.replace('{M}', PartMonthShortName);
			Result = Result.replace('{F}', PartMonthName);

			Result = Result.replace('{j}', PartDay);
			Result = Result.replace('{d}', PartDayDoubleDigit);

			Result = Result.replace('{G}', PartHour);
			Result = Result.replace('{H}', PartHourDoubleDigit);
			Result = Result.replace('{g}', PartHour12Hour);
			Result = Result.replace('{h}', PartHour12HourDoubleDigit);
			
			Result = Result.replace('{i}', PartMinuteDoubleDigit);
			Result = Result.replace('{s}', PartSecondDoubleDigit);

			Result = Result.replace('{a}', PartMedian);
			Result = Result.replace('{A}', PartMedianUppercase);

			//console.log('Result = ' + Result);
			return Result;
		}, 

		SecondToString: function(Value, ShowSecond = true, ShowMinute = true){
			var Second = Math.round(Math.abs(Value));
	
			var Minute = parseInt(Second / 60);
			Second = Second - (Minute * 60);
	
			var Hour = parseInt(Minute / 60);
			Minute = Minute - (Hour * 60);
	
			return (Value < 0 ? '-' : '') + Hour.toString().padStart(2, '0') + (ShowMinute ? ':' + Minute.toString().padStart(2, '0') : '') + (ShowMinute && ShowSecond ? ':' + Second.toString().padStart(2, '0') : '');
		},
	}, 

	Clipboard: {
		Copy: function(Content = null, Element = null){
			if(Element)Content = Element.value;
			navigator.clipboard.writeText(Content);
		}, 
	}, 

	sPHP: {
		HTML: {
			UI: {
				Progressbar: {
					Update: function ProgressbarUpdate(ProgressbarID, ProgressValue, Prefix = null, Suffix = null){
						if(Prefix){
							var objBarDataPrefix = document.getElementById(ProgressbarID + 'BarDataPrefix');
							objBarDataPrefix.innerHTML = Prefix;
							document.getElementById(ProgressbarID + 'DataPrefix').innerHTML = objBarDataPrefix.innerHTML;
						}
				
						var objBarDataValue = document.getElementById(ProgressbarID + 'BarDataValue');
						objBarDataValue.innerHTML = ProgressValue;
						document.getElementById(ProgressbarID + 'DataValue').innerHTML = objBarDataValue.innerHTML;
				
						if(Suffix){
							var objBarDataSuffix = document.getElementById(ProgressbarID + 'BarDataSuffix');
							objBarDataSuffix.innerHTML = Suffix;
							document.getElementById(ProgressbarID + 'DataSuffix').innerHTML = objBarDataSuffix.innerHTML;
						}
				
						document.getElementById(ProgressbarID + 'Bar').style.width = ProgressValue + '%';
				
						return true;
					}, 
				}, 
			}, 
		}, 
	}, 

	Graphics: {
		CopyCanvasToImage: function (SourceCanvas, TargetImage, SourceWidth, SourceHeight){
			if(SourceWidth == undefined)SourceWidth = SourceCanvas.width;
			if(SourceHeight == undefined)SourceHeight = SourceCanvas.height;

			var MemoryCanvas = document.createElement('canvas');
			MemoryCanvas.width = SourceWidth;
			MemoryCanvas.height = SourceHeight;
			MemoryCanvas.getContext('2d').putImageData(SourceCanvas.getContext('2d').getImageData(0, 0, SourceWidth, SourceHeight), 0, 0);
			
			TargetImage.width = SourceWidth;
			TargetImage.height = SourceHeight;						
			TargetImage.src = MemoryCanvas.toDataURL();
		}, 
	}, 

	LastScriptURL: function(){
		var objScript = document.getElementsByTagName('script');

		return objScript[objScript.length - 1].src;
	}, 

	Notify: function(Content, Title = null, Icon = null, NotificationDuration = 3000, Browser = true, sJS = false, Console = false, ItemCSSClass = ''){ //console.log('sJS.Notify()', Browser, sJS, Console);
		if(Browser)this.Browser.Notification.Create(Content, Title, Icon);
		if(sJS)this.DHTML.Notification(Content, NotificationDuration, Title, ItemCSSClass);
		if(Console)console.log('sJS: Notify: ' + Title + ': ' + Content);

		return true;
	}, 

	MakeTinyMCETextarea: function(objID){
		objTextarea = document.getElementById(objID);

		if(objTextarea){			
			objTextarea.style.width = objTextarea.offsetWidth + 'px';
		}
		else{
			console.log('sJS: MakeTinyMCETextarea: function(\'' + objID + '\'): Element not found!');
		}

		tinyMCE.execCommand('mceAddControl', false, objID);

		return true;
	},

	ToggleCheckBoxes: function(CheckBoxName, CheckedState, Inverse){
		objElements = document.getElementsByTagName('input');

		for(ElementCounter = 0; ElementCounter < objElements.length; ElementCounter++)if(
				objElements[ElementCounter].type=='checkbox'
			&&	(
						objElements[ElementCounter].name == CheckBoxName
					||	(
								objElements[ElementCounter].name.substring(0, CheckBoxName.length) == CheckBoxName
							&&	objElements[ElementCounter].name.substring(CheckBoxName.length, CheckBoxName.length+1)=='['
						)
				)
		){
			objElements[ElementCounter].checked = Inverse ? (objElements[ElementCounter].checked ? false : true) : CheckedState;
		}

		return true;
	},

	SetVisibilityByElemntID: function(ElementID, Visibility){
		//console.log('SetVisibilityByElemntID', ElementID, Visibility, document.getElementById(ElementID));
		document.getElementById(ElementID).style.display = Visibility ? '' : 'none';

		return true;
	},

	ToggleVisibilityByElemntID: function(ElementID){
		this.SetVisibilityByElemntID(ElementID, document.getElementById(ElementID).style.display == 'none' ? true : false);

		return true;
	},

	UUID: function(){ // https://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c){
			var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);

			return v.toString(16);
		});
	},

    SecondToTime: function(Value, ShowSecond = true, ShowMinute = true){ console.log('DEPRICATED: Use sJS.Time.SecondToString() instead');
		var Second = parseInt(Math.abs(Value));

		var Minute = parseInt(Second / 60);
		Second = Second - (Minute * 60);

		var Hour = parseInt(Minute / 60);
		Minute = Minute - (Hour * 60);

		return (Value < 0 ? '-' : '') + Hour.toString().padStart(2, '0') + (ShowMinute ? ':' + Minute.toString().padStart(2, '0') : '') + (ShowMinute && ShowSecond ? ':' + Second.toString().padStart(2, '0') : '');
    },

	CopyOfObject: function(ObjectToCopy){
		return JSON.parse(JSON.stringify(ObjectToCopy));
	}, 

	External: {
		ChartJS: {
			Dataset: {
				Toggle: function(ChartObject, DatasetIndex){
					if(!Array.isArray(DatasetIndex))DatasetIndex = [DatasetIndex];

					DatasetIndex.forEach(function(Item, Index){
						ChartObject.getDatasetMeta(Item).hidden = !ChartObject.getDatasetMeta(Item).hidden;
					})

					ChartObject.update();

					return true;
				},
			},
			Advance: function(Chart, Value, Label, Count, RightToLeft){
				ChartData = Chart.data;
	
				if(ChartData.labels.length == Count){
					if(RightToLeft){
						ChartData.datasets[0].data.shift();
						ChartData.labels.shift();
					}
					else{
						ChartData.datasets[0].data.pop();
						ChartData.labels.pop();
					}
				}
	
				if(RightToLeft){
					ChartData.datasets[0].data.push(Value);
					ChartData.labels.push(Label);
				}
				else{
					ChartData.datasets[0].data.splice(0, 0, Value);
					ChartData.labels.splice(0, 0, Label);
				}
	
				Chart.update();
	
				return true;
			}
		},
	},
}

function __HTTP_Transfer(URL, OnSuccess = function(Response, Header){}, Method = 'GET', Data = [], File = [], OnFail = function(StatusCode, ErrorMessage){}, Asynchronus = true, TimeOutMS = 5000){
	if(!TimeOutMS)TimeOutMS = 5000;
	
	HTTPCall = new XMLHttpRequest(); //console.log(URL);

	if(Asynchronus)HTTPCall.onreadystatechange = function(){
		if(this.readyState == XMLHttpRequest.DONE){
			if(this.status == 200){
				var ResponseHeader = {};
				var HeaderSplitter = ': ';

				HTTPCall.getAllResponseHeaders().split('\r\n').filter(function(Element){return Element != ''}).forEach(function(Header, HeaderIndex){
					SplitterPosition = Header.indexOf(HeaderSplitter);
					ResponseHeader[Header.substring(0, SplitterPosition).toLowerCase()] = Header.substring(SplitterPosition + HeaderSplitter.length);
				});

				OnSuccess(this.responseText, ResponseHeader);
			}
			else if(this.status == 0){
				OnFail(408, 'Time out of ' + TimeOutMS + ' ms');
			}
			else{
				OnFail(this.status, this.statusText);
			}
		}
	}

	HTTPCall.open(Method == 'POST' ? 'POST' : 'GET', URL, Asynchronus);
	HTTPCall.timeout = TimeOutMS; // time in milliseconds

	if(Method == 'POST'){
		POSTData = new FormData();
		for(DataName in Data)POSTData.append(DataName, Data[DataName]);
		for(FileName in File)POSTData.append(FileName, File[FileName]);
	}

	HTTPCall.send(Method == 'POST' ? POSTData : null);

	if(!Asynchronus)OnSuccess(HTTPCall.responseText, HTTPCall.getAllResponseHeaders());

	return true;
}