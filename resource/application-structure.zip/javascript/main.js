function SetStyleTheme(Theme){
	sJS.HTTP.Cookie('UI/Style/Theme', Theme, 30);
	//alert('Theme has been set to ' + Theme + '. Please click OK to reload the page with new theme.');
	window.location.href='./';

	return true;
}
